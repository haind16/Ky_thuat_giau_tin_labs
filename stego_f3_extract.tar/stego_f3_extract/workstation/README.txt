=== LAB: TACH TIN F3 (F3 EXTRACTION) ===

BUOC 0: Kiem tra anh stego
  file output/stego_f3.png
  exiftool output/stego_f3.png
  xxd output/stego_f3.png | head -4

BUOC 1: Scan header DCT
  python3 step1_inspect.py

BUOC 2: Giai ma header 32-bit
  python3 step2_header.py
  exiftool output/stego_f3.png

BUOC 3: Tach tin
  python3 step3_extract.py
  strings output/secret.txt

BUOC 4: Xac minh
  python3 step4_verify.py
  md5sum cover.png output/stego_f3.png

KHI XONG: stoplab
