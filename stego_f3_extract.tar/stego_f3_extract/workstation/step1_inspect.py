#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math

print("=" * 55)
print("  BUOC 1: KIEM TRA ANH STEGO")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

img = Image.open('output/stego_f3.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

print("File     : output/stego_f3.png")
print("Kich thuoc: {}x{} | {} block 8x8".format(W, H, (H//8)*(W//8)))

# Scan 100 block dau, dem nonzero AC
total_ac = nonzero_ac = risk1 = 0
for bi in range(min(H//8, 10)):
    for bj in range(W//8):
        b = arr[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        q = np.round(dct2d(b)/Q50).astype(np.int32)
        for u in range(8):
            for v in range(8):
                if u==0 and v==0: continue
                total_ac += 1
                if q[u,v] != 0: nonzero_ac += 1
                if abs(q[u,v]) == 1: risk1 += 1

print("100 block dau: AC nonzero={}/{} ({:.1f}%) | |q|=1: {}".format(
    nonzero_ac, total_ac, nonzero_ac/total_ac*100, risk1))

# Doc 32-bit header de biet payload length
ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]
bits = []
for bi in range(H//8):
    for bj in range(W//8):
        if len(bits) >= 32: break
        b = arr[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        q = np.round(dct2d(b)/Q50).astype(np.int32)
        for (r,c) in ZIGZAG[1:]:
            if len(bits) >= 32: break
            if q[r,c] == 0: continue
            coef = int(q[r,c])
            bits.append(abs(coef) % 2)
    if len(bits) >= 32: break

msg_len = 0
for b in bits[:32]:
    msg_len = (msg_len << 1) | b
print("Header 32-bit doc duoc: payload = {} bits = {} byte".format(msg_len, msg_len//8))
print("Uoc tinh can doc them: {} block".format(max(1, msg_len // max(nonzero_ac//100,1))))
print("\n[OK] Chay them: xxd output/stego_f3.png | head -4")
print("[DONE] BUOC 1 -- chay: python3 step2_header.py")
