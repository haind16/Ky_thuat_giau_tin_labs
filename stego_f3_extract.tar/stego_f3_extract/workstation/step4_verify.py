#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math

print("=" * 55)
print("  BUOC 4: XAC MINH VA PHAN TICH")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

cover = np.array(Image.open('cover.png').convert('L'), dtype=np.float64)
stego = np.array(Image.open('output/stego_f3.png').convert('L'), dtype=np.float64)
diff  = np.abs(cover - stego)
mse   = np.mean(diff**2)
psnr  = 10*math.log10(255**2/mse) if mse > 0 else 999.0

print("PSNR     : {:.2f} dB".format(psnr))
print("Diff max : {} | mean: {:.4f}".format(int(diff.max()), diff.mean()))
print("Pixel thay doi: {}/{} ({:.2f}%)".format(
    int((diff>0).sum()), int(cover.size),
    float((diff>0).sum())/float(cover.size)*100))

# Dem he so =0 moi (shrinkage signature)
c0_cover = c0_stego = 0
for bi in range(cover.shape[0]//8):
    for bj in range(cover.shape[1]//8):
        bc = cover[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        bs = stego[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        qc = np.round(dct2d(bc)/Q50).astype(np.int32)
        qs = np.round(dct2d(bs)/Q50).astype(np.int32)
        for (r,c) in ZIGZAG[1:]:
            if qc[r,c] != 0: c0_cover += (qc[r,c] == 0)
            if qs[r,c] == 0 and qc[r,c] != 0: c0_stego += 1

print("\nShrinkage signature: {} he so 0 moi".format(c0_stego))
print("-> F3 confirmed: {}".format("YES" if c0_stego > 5 else "NO"))

# Bản đồ ASCII diff
print("\nBan do diff 64x64 (goc trai tren):")
for r in range(0, 64, 2):
    row = ""
    for c in range(0, 64, 2):
        v = float(np.sum(diff[r:r+2, c:c+2]))
        row += "." if v==0 else ("*" if v<3 else "X")
    print("  " + row)
print("(. giong | * nhe | X khac nhieu)")

# Doc va hien thi secret
try:
    with open('output/secret.txt') as f:
        msg = f.read().strip()
    print("\nSecret: '{}'".format(msg))
except:
    print("\n[LOI] Chua co output/secret.txt")

print("\n[OK] Chay them: compare cover.png output/stego_f3.png -highlight-color Red output/diff_compare.png")
print("[DONE] BUOC 4 -- chay: stoplab")
