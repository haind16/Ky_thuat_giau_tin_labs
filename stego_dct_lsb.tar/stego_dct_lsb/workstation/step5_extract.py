#!/usr/bin/env python3
"""BUOC 5: TACH TIN TU ANH STEGO"""
import numpy as np
from PIL import Image
import math, os, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N=8; out=np.zeros((N,N))
    for u in range(N):
        for v in range(N):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            s=sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                  for j in range(N) for k in range(N))
            out[u,v]=0.25*cu*cv*s
    return out

print("=" * 58)
print("  BUOC 5: TACH TIN TU ANH STEGO")
print("=" * 58)

if not os.path.exists('output/stego_lsb.png'):
    print("[LOI] Chua co output/stego_lsb.png!")
    exit(1)

# Doc so bits can tach tu embed_result.json
if not os.path.exists('embed_result.json'):
    print("[LOI] Chua co embed_result.json. Chay step4_embed.py truoc!")
    exit(1)

with open('embed_result.json') as f:
    result = json.load(f)
bits_embedded = result['bits_embedded']
original_msg = result['message']

img = Image.open('output/stego_lsb.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

# Tach dung so bits da giau
bits = []
for bi in range(H//8):
    for bj in range(W//8):
        if len(bits) >= bits_embedded: break
        r0,c0 = bi*8,bj*8
        block = arr[r0:r0+8,c0:c0+8]-128.0
        q = np.round(dct2d(block)/Q50).astype(np.int32)
        for (r,c) in ZIGZAG[5:31]:
            if len(bits) >= bits_embedded: break
            if q[r,c] == 0: continue
            v = int(q[r,c])
            bits.append(v&1 if v>0 else (-v)&1)

HEADER = 32
print("\n[BUOC 5.1] Doc header 32 bits dau:")
print("  Bits: {} {}".format(
    ''.join(str(b) for b in bits[:16]),
    ''.join(str(b) for b in bits[16:32])))

msg_len = 0
for b in bits[:32]:
    msg_len = (msg_len << 1) | b
print("  => Payload dai: {} bits = {} ky tu".format(msg_len, msg_len//8))

# Kiem tra hop ly
if msg_len > 10000 or msg_len <= 0:
    print("[CANH BAO] msg_len bat thuong: {}. Dung embed_result de giai ma.".format(msg_len))
    msg_len = result['bits_embedded'] - 32

print("\n[BUOC 5.2] Giai ma tung ky tu:")
msg_bits = bits[HEADER:HEADER+msg_len]
chars = []
for i in range(0, len(msg_bits)-7, 8):
    v = sum(msg_bits[i+j]<<(7-j) for j in range(8))
    try:
        c = chr(v)
        if 32 <= v <= 126:
            chars.append(c)
            if i < 40:
                print("  Bits {}-{}: {} = {} = '{}'".format(
                    i, i+7,
                    ''.join(str(b) for b in msg_bits[i:i+8]),
                    v, c))
        else:
            chars.append('?')
    except:
        chars.append('?')

message = ''.join(chars)
print("\n[KET QUA]")
print("  Thong diep tach duoc: '{}'".format(message))
print("  Thong diep goc      : '{}'".format(original_msg))
print("  Kiem tra: {}".format("CHINH XAC!" if message==original_msg else "SAI - co loi!"))

print("\n[NHIEM VU CUA BAN]")
print("  Thu doi noi dung message.txt va chay lai tu buoc 2:")
print("    echo 'Noi dung khac' > message.txt")
print("    python3 step2_binary.py")
print("    python3 step4_embed.py")
print("    python3 step5_extract.py")
print()
print("[NEXT] Chay: python3 step6_compare.py")
