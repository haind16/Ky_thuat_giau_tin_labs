=== LAB 3: GIAU TIN DCT-LSB - PIPELINE CHI TIET ===

Muc tieu: Hieu toan bo quy trinh giau tin DCT-LSB
          bao gom ca cac buoc lam tay

QUY TRINH:
  Buoc 0: python3 gen_cover.py           - Tao anh test
  Buoc 1: python3 step1_view.py          - Xem anh, doc huong dan tao message
  ----> LAM TAY: tao message.txt <----
        echo 'Noi dung cua ban' > message.txt
  Buoc 2: python3 step2_binary.py        - Xem qua trinh chuyen nhi phan
  ----> LAM TAY: kiem tra payload_bits.json, thu tinh tay bit <----
  Buoc 3: python3 step3_dct_inspect.py   - Xem he so DCT, hieu LSB hoat dong
  ----> LAM TAY: tu tinh LSB cua he so DCT bang python3 -c <----
  Buoc 4: python3 step4_embed.py         - Giau tin, xem qua trinh chi tiet
  ----> LAM TAY: xxd cover.png vs stego_lsb.png, ls -lh <----
  Buoc 5: python3 step5_extract.py       - Tach tin, xem giai ma tung bit
  ----> LAM TAY: thu doi message.txt va chay lai <----
  Buoc 6: python3 step6_compare.py       - So sanh, tra loi cau hoi vao answer.txt
  ----> LAM TAY: nano answer.txt <----

Khi xong: stoplab
