#!/usr/bin/env python3
"""BUOC 4: GIAU TIN - CHAY SCRIPT, QUAN SAT OUTPUT CHI TIET"""
import numpy as np
from PIL import Image
import math, json, os

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N=8; out=np.zeros((N,N))
    for u in range(N):
        for v in range(N):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            s=sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                  for j in range(N) for k in range(N))
            out[u,v]=0.25*cu*cv*s
    return out

def idct2d(block):
    N=8; out=np.zeros((N,N))
    for j in range(N):
        for k in range(N):
            s=sum((1/math.sqrt(2) if u==0 else 1)*(1/math.sqrt(2) if v==0 else 1)*
                  block[u,v]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                  for u in range(N) for v in range(N))
            out[j,k]=0.25*s
    return out

if not os.path.exists('payload_bits.json'):
    print("[LOI] Chay step2_binary.py truoc!")
    exit(1)

with open('payload_bits.json') as f:
    data = json.load(f)
bits = data['bits']
msg = data['message']

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape
stego = arr.copy()

print("=" * 58)
print("  BUOC 4: GIAU TIN BANG DCT-LSB")
print("=" * 58)
print("\n  Thong diep : '{}'".format(msg))
print("  Tong bits  : {}".format(len(bits)))
print("\n[QUA TRINH GIAU - 15 BUOC DAU TIEN]")
print("  {:<5} {:<8} {:<6} {:<8} {:<8} {}".format(
    "Bit#", "Khoi", "Zigzag", "He so cu", "He so moi", "Bit giau"))
print("  " + "-" * 48)

bit_idx = 0
blocks_used = 0
shown = 0

for bi in range(H//8):
    for bj in range(W//8):
        if bit_idx >= len(bits): break
        r0,c0 = bi*8, bj*8
        block = arr[r0:r0+8,c0:c0+8] - 128.0
        dct_b = dct2d(block)
        q = np.round(dct_b/Q50).astype(np.int32)
        changed = False
        for idx,(r,c) in enumerate(ZIGZAG[5:31]):
            if bit_idx >= len(bits): break
            if q[r,c] == 0: continue
            bit = bits[bit_idx]
            old = int(q[r,c])
            q[r,c] = (q[r,c]&~1)|bit if q[r,c]>0 else -((-q[r,c]&~1)|bit)
            new = int(q[r,c])
            if shown < 15:
                changed_mark = " <-- THAY DOI" if old != new else ""
                print("  {:<5} {:<8} {:<6} {:<8} {:<8} {}{}".format(
                    bit_idx, "({},{})".format(bi,bj),
                    idx+5, old, new, bit, changed_mark))
            elif shown == 15:
                print("  ... ({} bits con lai)".format(len(bits)-bit_idx))
            shown += 1
            bit_idx += 1
            changed = True
        if changed: blocks_used += 1
        dq = q.astype(np.float64)*Q50
        rec = idct2d(dq)+128.0
        stego[r0:r0+8,c0:c0+8] = np.clip(np.round(rec),0,255)

os.makedirs('output', exist_ok=True)
Image.fromarray(stego.astype(np.uint8),'L').save('output/stego_lsb.png')

mse = np.mean((arr-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse > 0 else float('inf')
changed_px = int((np.abs(arr-stego)>0).sum())

print("\n[KET QUA]")
print("  Bits da giau   : {}/{}".format(bit_idx, len(bits)))
print("  Khoi su dung   : {}".format(blocks_used))
print("  Pixel thay doi : {} ({:.2f}%)".format(changed_px, changed_px*100/(H*W)))
print("  PSNR           : {:.4f} dB".format(psnr))
print("  Anh stego      : output/stego_lsb.png")

with open('embed_result.json','w') as f:
    json.dump({'psnr': round(psnr,4), 'message': msg,
               'bits_embedded': bit_idx, 'blocks_used': blocks_used}, f)

print("\n[NHIEM VU SAU KHI CHAY]")
print("  1. So sanh kich thuoc 2 anh:")
print("     ls -lh cover.png output/stego_lsb.png")
print()
print("  2. Xem byte dau tien cua 2 file co khac nhau khong:")
print("     xxd cover.png | head -5")
print("     xxd output/stego_lsb.png | head -5")
print()
print("[NEXT] Chay: python3 step5_extract.py")
