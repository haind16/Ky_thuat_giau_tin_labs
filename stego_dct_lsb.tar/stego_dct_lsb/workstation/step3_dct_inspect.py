#!/usr/bin/env python3
"""
BUOC 3: QUAN SAT HE SO DCT - SINH VIEN TU SUA HE SO
Script nay hien thi he so DCT cua khoi dau tien
Sau do sinh vien tu sua 1 he so bang tay de hieu LSB hoat dong
"""
import numpy as np
from PIL import Image
import math, json, os

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N = 8
    out = np.zeros((N,N))
    for u in range(N):
        for v in range(N):
            cu = 1/math.sqrt(2) if u==0 else 1.0
            cv = 1/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
block = arr[0:8, 0:8] - 128.0
dct_b = dct2d(block)
q = np.round(dct_b / Q50).astype(np.int32)

print("=" * 58)
print("  BUOC 3: QUAN SAT HE SO DCT KHOI DAU TIEN")
print("=" * 58)

print("\n[A] He so DCT sau luong tu hoa (ma tran 8x8):")
for i in range(8):
    print("  " + " ".join("{:5d}".format(q[i,j]) for j in range(8)))

print("\n[B] He so theo thu tu ZIGZAG (chi mid-freq index 5-30):")
print("  {:<8} {:<10} {:<8} {:<6} {}".format(
    "Index", "Vi tri(r,c)", "He so", "LSB", "Bit co the giau"))
print("  " + "-" * 50)
for i, (r,c) in enumerate(ZIGZAG[5:16]):
    v = int(q[r,c])
    if v != 0:
        lsb = v & 1 if v > 0 else (-v) & 1
        print("  {:<8} {:<10} {:<8} {:<6} {}".format(
            i+5, "({},{})".format(r,c), v, lsb,
            "<-- co the giau 0 hoac 1"))
    else:
        print("  {:<8} {:<10} {:<8} {:<6} {}".format(
            i+5, "({},{})".format(r,c), v, "-", "Bo qua (= 0)"))

# Luu he so ra file JSON de sinh vien co the sua
coeff_data = {}
for i, (r,c) in enumerate(ZIGZAG[5:31]):
    coeff_data[str(i+5)] = {'r': int(r), 'c': int(c), 'value': int(q[r,c])}
with open('dct_coeffs.json', 'w') as f:
    json.dump(coeff_data, f, indent=2)

print("\n[C] Da luu he so vao file dct_coeffs.json")
print()
print("[NHIEM VU CUA BAN - LAM TAY]")
print("  1. Xem file he so DCT:")
print("     cat dct_coeffs.json")
print()
print("  2. Tim 1 he so != 0, vi du index 5 co gia tri la bao nhieu?")
print("     Neu he so = 13 (le), LSB = 1")
print("     Neu he so = 12 (chan), LSB = 0")
print()
print("  3. Thu tinh tay: neu he so = 13, muon giau bit 0 thi sua thanh bao nhieu?")
print("     python3 -c \"v=13; bit=0; print((v & ~1) | bit)\"")
print()
print("  4. Neu he so = -7, muon giau bit 1 thi tinh the nao?")
print("     python3 -c \"v=-7; bit=1; print(-((-v & ~1) | bit))\"")
print()
print("[NEXT] Sau khi hieu, chay: python3 step4_embed.py")
