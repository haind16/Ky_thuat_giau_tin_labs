#!/usr/bin/env python3
"""BUOC 2: Hien thi qua trinh chuyen sang nhi phan - sinh vien quan sat"""
import os, json

print("=" * 58)
print("  BUOC 2: CHUYEN THONG DIEP SANG NHI PHAN")
print("=" * 58)

if not os.path.exists('message.txt'):
    print("[LOI] Chua co message.txt!")
    print("  Chay: echo 'Noi dung can giau' > message.txt")
    exit(1)

with open('message.txt') as f:
    msg = f.read().strip()

print("\n[THONG DIEP]: '{}'".format(msg))
print("  Do dai: {} ky tu = {} bits\n".format(len(msg), len(msg)*8))

print("[CHI TIET CHUYEN DOI TUNG KY TU]")
print("  {:<8} {:<6} {:<8} {}".format("Ky tu", "ASCII", "Hex", "Nhi phan (8 bits)"))
print("  " + "-" * 48)

all_bits = []
for c in msg:
    v = ord(c)
    bits = [(v >> (7-i)) & 1 for i in range(8)]
    all_bits.extend(bits)
    print("  {:<8} {:<6} {:<8} {}  {}".format(
        repr(c), v, hex(v),
        ''.join(str(b) for b in bits[:4]),
        ''.join(str(b) for b in bits[4:])))

print("\n[HEADER 32-BIT]")
msg_bit_len = len(all_bits)
header = [(msg_bit_len >> (31-i)) & 1 for i in range(32)]
print("  Luu do dai payload: {} bits".format(msg_bit_len))
print("  Header: {} {}".format(
    ''.join(str(b) for b in header[:16]),
    ''.join(str(b) for b in header[16:])))

full = header + all_bits
print("\n[PAYLOAD HOAN CHINH]")
print("  Header (32 bits) + Data ({} bits) = {} bits tong".format(
    len(all_bits), len(full)))
print("  16 bits dau: {}".format(''.join(str(b) for b in full[:16])))
print("  16 bits cuoi: {}".format(''.join(str(b) for b in full[-16:])))

with open('payload_bits.json', 'w') as f:
    json.dump({'bits': full, 'message': msg}, f)

print("\n[OK] Da luu vao payload_bits.json")
print("\n[NHIEM VU CUA BAN]")
print("  Kiem tra file vua tao:")
print("    cat payload_bits.json | python3 -c \"import json,sys; d=json.load(sys.stdin); print('Tong bits:', len(d['bits']))\"")
print()
print("  Thu tinh tay: ky tu 'A' = ASCII 65 = nhi phan la gi?")
print("    python3 -c \"print(bin(65))\"")
print()
print("[NEXT] Chay: python3 step3_dct_inspect.py")
