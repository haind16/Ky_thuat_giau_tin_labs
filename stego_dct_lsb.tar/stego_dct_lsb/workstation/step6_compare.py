#!/usr/bin/env python3
"""BUOC 6: SO SANH VA PHAN TICH"""
import numpy as np
from PIL import Image
import math, json, os

print("=" * 58)
print("  BUOC 6: SO SANH ANH GOC VS STEGO + PHAN TICH")
print("=" * 58)

cover = np.array(Image.open('cover.png').convert('L'), dtype=np.float64)
stego = np.array(Image.open('output/stego_lsb.png').convert('L'), dtype=np.float64)
H, W = cover.shape
diff = np.abs(cover-stego)
mse = np.mean((cover-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse>0 else float('inf')
changed = int((diff>0).sum())

print("\n[1] CHI SO CHAT LUONG")
print("  PSNR : {:.4f} dB  {}".format(psnr,
    "(XUAT SAC >= 40dB)" if psnr>=40 else "(TOT >= 35dB)" if psnr>=35 else "(TRUNG BINH)"))
print("  MSE  : {:.6f}".format(mse))
print("  Pixel thay doi: {}/{} ({:.2f}%)".format(changed, H*W, changed*100/(H*W)))
print("  Max diff      : {:.0f}  Mean diff: {:.4f}".format(diff.max(), diff.mean()))

print("\n[2] HISTOGRAM SO SANH")
ch = np.zeros(256,int); sh = np.zeros(256,int)
for v in cover.flatten().astype(int): ch[v]+=1
for v in stego.flatten().astype(int): sh[v]+=1
dh = np.abs(ch-sh)
print("  Tong chenh lech histogram: {}".format(dh.sum()))
print("  Phan phoi pixel (buoc 16):")
print("  {:<8} {:<10} {:<10} {}".format("Gia tri","Goc","Stego","Chenh lech"))
for v in range(0,256,16):
    mark = " <--" if abs(ch[v]-sh[v])>0 else ""
    print("  {:<8} {:<10} {:<10} {}{}".format(
        v, ch[v], sh[v], sh[v]-ch[v], mark))

print("\n[3] SO SANH PIXEL KHOI DAU TIEN]")
cb = cover[0:8,0:8].astype(int)
sb = stego[0:8,0:8].astype(int)
print("  Goc  :", " ".join("{:4d}".format(cb[0,j]) for j in range(8)))
print("  Stego:", " ".join("{:4d}".format(sb[0,j]) for j in range(8)))
print("  Diff :", " ".join("{:4d}".format(abs(cb[0,j]-sb[0,j])) for j in range(8)))

print("\n[4] CAU HOI PHAN TICH - TRA LOI VAO answer.txt]")
print("  Q1: PSNR = {:.2f} dB. Mat nguoi co phat hien duoc khong?".format(psnr))
print("  Q2: Chi {}% pixel thay doi. DCT-LSB tot hon Spatial-LSB o diem nao?".format(
    round(changed*100/(H*W),2)))
print("  Q3: Histogram chenh lech = {}. So sanh voi anh binh thuong?".format(dh.sum()))
print("  Q4: Neu nen lai anh PNG nay sang JPEG, tin co con lay duoc khong?")
print("  Q5: Mid-freq zigzag 5-30 tot hon low-freq 0-4 de giau tin vi sao?")

print("\n[NHIEM VU CUOI]")
print("  Ghi tra loi vao answer.txt:")
print("    nano answer.txt")
print()
print("  Kiem tra lai:")
print("    cat answer.txt")
print()
print("[XONG] Chay stoplab de ket thuc lab!")
