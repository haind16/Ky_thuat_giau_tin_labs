#!/usr/bin/env python3
"""BUOC 1: Xem thong tin anh va huong dan tao message"""
import numpy as np
from PIL import Image
import os

print("=" * 58)
print("  BUOC 1: XEM THONG TIN ANH VA CHUAN BI THONG DIEP")
print("=" * 58)

if not os.path.exists('cover.png'):
    print("[LOI] Chua co cover.png. Chay: python3 gen_cover.py")
    exit(1)

img = Image.open('cover.png').convert('L')
arr = np.array(img)
H, W = arr.shape

print("\n[ANH GOC: cover.png]")
print("  Kich thuoc : {} x {} pixels".format(W, H))
print("  So khoi    : {} x {} = {} khoi 8x8".format(W//8, H//8, (W//8)*(H//8)))
print("  Pixel min  : {}  max: {}  TB: {:.2f}".format(
    int(arr.min()), int(arr.max()), float(arr.mean())))

max_chars = ((W//8) * (H//8) * 26) // 8 - 4
print("\n[DUNG LUONG GIAU TIN]")
print("  Toi da khoang {} ky tu".format(max_chars))

print("\n[NHIEM VU CUA BAN]")
print("  Tao file message.txt chua noi dung can giau.")
print("  Goi y cac lenh:")
print()
print("    Cach 1 - Dung echo:")
print("    echo 'Noi dung can giau' > message.txt")
print()
print("    Cach 2 - Dung nano (trinh soan thao):")
print("    nano message.txt")
print("    (Gõ noi dung, Ctrl+O de luu, Ctrl+X de thoat)")
print()
print("    Cach 3 - Nhieu dong:")
print("    printf 'PTIT_B22DCAT107\\nAnToanThongTin' > message.txt")
print()
print("  Sau khi tao xong, kiem tra noi dung:")
print("    cat message.txt")
print("    wc -c message.txt  (dem so ky tu)")
print()
print("[NEXT] Sau khi tao message.txt, chay: python3 step2_binary.py")
