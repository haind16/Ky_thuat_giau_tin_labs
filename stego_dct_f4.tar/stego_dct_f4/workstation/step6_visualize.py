#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [(0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]

def dct2d(block):
    N=8; out=np.zeros((N,N))
    for u in range(N):
        for v in range(N):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(
                block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                for j in range(N) for k in range(N))
    return out

def get_dct_histogram(filename):
    img = Image.open(filename).convert('L')
    arr = np.array(img, dtype=np.float64)
    H, W = arr.shape
    hist = {i: 0 for i in range(1, 9)} 
    
    for bi in range(H//8):
        for bj in range(W//8):
            r0, c0 = bi*8, bj*8
            block = arr[r0:r0+8, c0:c0+8] - 128.0
            q = np.round(dct2d(block)/Q50).astype(np.int32)
            for (r,c) in ZIGZAG[5:31]:
                v = abs(int(q[r,c]))
                if v in hist:
                    hist[v] += 1
    return hist

print("=" * 70)
print("  BUOC 6: TRUC QUAN HOA BIEU DO DCT (LSB vs F4)")
print("=" * 70)
print("\n[*] Dang phan tich he so DCT cua 3 anh, vui long doi...\n")

cov_h = get_dct_histogram('cover.png')
lsb_h = get_dct_histogram('output/stego_lsb.png')
f4_h  = get_dct_histogram('output/stego_f4.png')

print(" He So |  Cover (Goc)         |  LSB Stego           |  F4 Stego")
print("-" * 70)

max_val = max(max(cov_h.values()), max(lsb_h.values()), max(f4_h.values()))

for v in range(2, 8):
    c_bar = '*' * int((cov_h[v] / max_val) * 15)
    l_bar = '*' * int((lsb_h[v] / max_val) * 15)
    f_bar = '*' * int((f4_h[v] / max_val) * 15)
    
    print("  {:3d}  | {:5d} {:<12} | {:5d} {:<12} | {:5d} {:<12}".format(
        v, cov_h[v], c_bar, lsb_h[v], l_bar, f4_h[v], f_bar))

print("\n>> NGHICH LY F4:")
print(">> LSB: De y cap 2-3 hoac 4-5 co xu huong san bang nhau (Pair of Values).")
print(">> F4 : Giu duoc do doc tu nhien cua he so DCT, an toan tuyet doi ve toan hoc.")
print("\n[XONG] Chay stoplab de ket thuc lab!")
