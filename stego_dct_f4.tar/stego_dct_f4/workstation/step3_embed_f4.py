#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, json, os

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)
ZIGZAG = [(0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]
def dct2d(block):
    N=8; out=np.zeros((N,N))
    for u in range(N):
        for v in range(N):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(N) for k in range(N))
    return out
def idct2d(block):
    N=8; out=np.zeros((N,N))
    for j in range(N):
        for k in range(N):
            out[j,k]=0.25*sum((1/math.sqrt(2) if u==0 else 1)*(1/math.sqrt(2) if v==0 else 1)*block[u,v]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for u in range(N) for v in range(N))
    return out
def f4_embed(coeff, bit):
    if coeff == 0: return None
    lsb = coeff&1 if coeff>0 else (-coeff)&1
    if lsb == bit: return coeff
    new = coeff-1 if coeff>0 else coeff+1
    return None if new==0 else new
with open('message.txt') as f:
    msg = f.read().strip()
payload = []
for c in msg:
    v = ord(c)
    payload.extend([(v>>(7-i))&1 for i in range(8)])
img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape
stego = arr.copy()
all_q = np.zeros((H, W), dtype=np.int32)
# mask: 1 = vi tri nay co chua bit that, 0 = shrinkage hoac zero
embed_mask = np.zeros((H, W), dtype=np.int8)
bit_idx = 0
shrink = 0
for bi in range(H//8):
    for bj in range(W//8):
        r0,c0 = bi*8,bj*8
        block = arr[r0:r0+8,c0:c0+8]-128.0
        q = np.round(dct2d(block)/Q50).astype(np.int32)
        if bit_idx < len(payload):
            for (r,c) in ZIGZAG[5:31]:
                if bit_idx >= len(payload): break
                new = f4_embed(int(q[r,c]), payload[bit_idx])
                if new is None:
                    shrink += 1
                    continue
                q[r,c] = new
                embed_mask[r0+r, c0+c] = 1  # danh dau vi tri co bit that
                bit_idx += 1
        for (r,c) in ZIGZAG:
            all_q[r0+r, c0+c] = q[r,c]
        dq = q.astype(np.float64)*Q50
        stego[r0:r0+8,c0:c0+8] = np.clip(np.round(idct2d(dq)+128.0),0,255)
os.makedirs('output', exist_ok=True)
Image.fromarray(stego.astype(np.uint8),'L').save('output/stego_f4.png')
np.save('output/coeffs_f4.npy', all_q)
np.save('output/mask_f4.npy', embed_mask)
mse = np.mean((arr-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse>0 else float('inf')
changed = int((np.abs(arr-stego)>0).sum())
with open('output/key_f4.json','w') as f:
    json.dump({'msg':msg,'nbits':len(payload),'method':'F4','shrinkage':shrink}, f)
ch=[0]*256; sh=[0]*256
for v in arr.flatten().astype(int): ch[v]+=1
for v in stego.flatten().astype(int): sh[v]+=1
with open('output/hist_f4.json','w') as f:
    json.dump({'cover':ch,'stego':sh,'psnr':round(psnr,4),'changed':changed,'shrinkage':shrink,'method':'F4','msg':msg}, f)
print("[F4]  Giau xong: {} bits | PSNR={:.2f}dB | Pixel doi={} ({:.1f}%) | Shrinkage={}".format(bit_idx,psnr,changed,changed*100/(H*W),shrink))
print("Coefficients: output/coeffs_f4.npy")
print("Mask        : output/mask_f4.npy")
print("Anh         : output/stego_f4.png")
print()
print(">> cat output/key_f4.json")
print(">> ls -lh output/")
print(">> Next: python3 step4_extract.py")
