#!/usr/bin/env python3
import numpy as np
from PIL import Image
import os

img = Image.open('cover.png').convert('L')
arr = np.array(img)
H, W = arr.shape

print("Anh: {}x{} | {} khoi 8x8".format(W, H, (W//8)*(H//8)))
print("Pixel min/max/TB: {}/{}/{:.1f}".format(arr.min(), arr.max(), arr.mean()))

if not os.path.exists('message.txt'):
    with open('message.txt', 'w') as f:
        f.write('PTIT_F4_Steganography')

with open('message.txt') as f:
    msg = f.read().strip()

print("Message: '{}' ({} ky tu = {} bits)".format(msg, len(msg), len(msg)*8))
print()
print(">> Sua message: echo 'Noi dung moi' > message.txt")
print(">> Xem message: cat message.txt")
print(">> Next: python3 step2_embed_lsb.py")
