#!/usr/bin/env python3
"""So sanh LSB vs F4: PSNR, histogram, he so DCT"""
import numpy as np
from PIL import Image
import math, json, os

def psnr(a, b):
    mse = np.mean((a.astype(float)-b.astype(float))**2)
    return 10*math.log10(255**2/mse) if mse>0 else float('inf')

cover = np.array(Image.open('cover.png').convert('L'))
lsb   = np.array(Image.open('output/stego_lsb.png').convert('L'))
f4    = np.array(Image.open('output/stego_f4.png').convert('L'))

p_lsb = psnr(cover, lsb)
p_f4  = psnr(cover, f4)
ch_lsb = int((np.abs(cover.astype(int)-lsb.astype(int))>0).sum())
ch_f4  = int((np.abs(cover.astype(int)-f4.astype(int))>0).sum())
N = cover.size

print("=" * 52)
print("  SO SANH DCT-LSB vs F4")
print("=" * 52)
print("{:<20} {:>12} {:>12}".format("Chi so", "LSB", "F4"))
print("-" * 52)
print("{:<20} {:>12.4f} {:>12.4f}".format("PSNR (dB)", p_lsb, p_f4))
print("{:<20} {:>12} {:>12}".format("Pixel thay doi", ch_lsb, ch_f4))
print("{:<20} {:>11.1f}% {:>11.1f}%".format("% pixel doi", ch_lsb*100/N, ch_f4*100/N))

# Histogram diff
ch = [0]*256; lh = [0]*256; fh = [0]*256
for v in cover.flatten(): ch[int(v)]+=1
for v in lsb.flatten():   lh[int(v)]+=1
for v in f4.flatten():    fh[int(v)]+=1
dl = sum(abs(ch[i]-lh[i]) for i in range(256))
df = sum(abs(ch[i]-fh[i]) for i in range(256))
print("{:<20} {:>12} {:>12}".format("Histogram diff", dl, df))

print()
print("Histogram (buoc 32) - Chenh lech so voi anh goc:")
print("{:<8} {:>10} {:>10}".format("Gia tri","LSB-Goc","F4-Goc"))
for v in range(0, 256, 32):
    print("{:<8} {:>10} {:>10}".format(v, lh[v]-ch[v], fh[v]-ch[v]))

# Doc thong tin F4 shrinkage
if os.path.exists('output/hist_f4.json'):
    with open('output/hist_f4.json') as f:
        d = json.load(f)
    print()
    print("F4 shrinkage (he so bi bo qua): {}".format(d.get('shrinkage',0)))

print()
print("NHAN XET:")
print("  LSB: thay the truc tiep -> histogram lech khong doi xung")
print("  F4 : chi giam |he so|   -> histogram doi xung hon, kho phat hien")
print()
print(">> Tra loi vao answer.txt: nano answer.txt")
print(">> Q1: F4 co PSNR cao hon hay thap hon LSB? Vi sao?")
print(">> Q2: Histogram diff cua F4 nho hon LSB co nghia gi?")
print(">> Q3: Shrinkage anh huong the nao den dung luong giau tin?")
print(">> Q4: F4 co the chong lai pha SPA (Sample Pair Analysis) tot hon LSB vi sao?")
print()
print(">> Xong: stoplab")
