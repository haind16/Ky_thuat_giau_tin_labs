=== LAB 4: GIAU TIN DCT - SO SANH LSB vs F4 ===

QUY TRINH:
  B0: python3 gen_cover.py
  B1: python3 step1_prepare.py
      >> LAM TAY: echo 'Noi dung can giau' > message.txt
  B2: python3 step2_embed_lsb.py
  B3: python3 step3_embed_f4.py
  B4: python3 step4_extract.py f4
      >> LAM TAY: python3 step4_extract.py lsb
  B5: python3 step5_compare.py
      >> LAM TAY: nano answer.txt
  B6: python3 step6_visualize.py
      >> LAM TAY: Quan sat bieu do ASCII Histogram tren terminal de thay hien tuong PoV

Khi xong: stoplab
