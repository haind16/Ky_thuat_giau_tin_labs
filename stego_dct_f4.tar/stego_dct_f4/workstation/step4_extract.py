#!/usr/bin/env python3
import numpy as np
import json, sys, os

ZIGZAG = [(0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]

mode = sys.argv[1] if len(sys.argv) > 1 else 'f4'
coeffs_file = 'output/coeffs_{}.npy'.format(mode)
key_file    = 'output/key_{}.json'.format(mode)
mask_file   = 'output/mask_{}.npy'.format(mode)

if not os.path.exists(coeffs_file):
    print("[LOI] Khong tim thay", coeffs_file)
    exit(1)

with open(key_file) as f:
    key = json.load(f)
nbits    = key['nbits']
original = key['msg']

all_q = np.load(coeffs_file)
H, W  = all_q.shape

# Dung mask neu co (F4)
use_mask = os.path.exists(mask_file)
mask = np.load(mask_file) if use_mask else None

bits = []
for bi in range(H//8):
    for bj in range(W//8):
        if len(bits) >= nbits: break
        r0,c0 = bi*8, bj*8
        for (r,c) in ZIGZAG[5:31]:
            if len(bits) >= nbits: break
            v = int(all_q[r0+r, c0+c])
            
            # Logic bo qua (skip) tach rieng cho tung thuat toan
            if mode == 'lsb':
                if abs(v) <= 1: continue  # LSB bo qua he so thuoc tap {-1, 0, 1}
            elif mode == 'f4':
                if mask is not None and mask[r0+r, c0+c] == 0:
                    continue  # F4 bo qua vi tri shrinkage hoac zero goc
                elif mask is None and v == 0:
                    continue
            
            bits.append(v&1 if v>0 else (-v)&1)

chars = []
for i in range(0, len(bits)-7, 8):
    val = sum(bits[i+j]<<(7-j) for j in range(8))
    chars.append(chr(val) if 32<=val<=126 else '?')
message = ''.join(chars)

print("[{}] Tach tin: '{}'".format(mode.upper(), message))
print("Goc       : '{}'".format(original))
print("Ket qua   : {}".format("CHINH XAC" if message==original else "SAI"))
print()
print(">> Thu mode khac: python3 step4_extract.py lsb")
print(">> Next: python3 step5_compare.py")
