#!/usr/bin/env python3
import numpy as np
from PIL import Image
import os

if not os.path.exists('cover.png'):
    print("[LOI] Chua co cover.png. Chay gen_cover.py truoc!")
    exit(1)

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

print("=" * 48)
print("  BUOC 2: CHIA KHOI 8x8")
print("=" * 48)
print("  Kich thuoc anh grayscale: {} x {}".format(W, H))
print("  So khoi 8x8 theo chieu ngang: {}".format(W // 8))
print("  So khoi 8x8 theo chieu doc  : {}".format(H // 8))
print("  Tong so khoi 8x8            : {}".format((W // 8) * (H // 8)))
print("")

# Lay khoi dau tien (0,0)
block = arr[0:8, 0:8]
print("  Khoi 8x8 goc (0,0) TRUOC khi tru 128:")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:6.1f}".format(block[i, j])
    print(row)

block_shifted = block - 128.0
print("")
print("  Khoi 8x8 goc (0,0) SAU khi tru 128 (chuan hoa):")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:6.1f}".format(block_shifted[i, j])
    print(row)

print("")
print("[LY THUYET] Tru 128 de can bang gia tri quanh 0, DCT hieu qua hon.")
print("[OK] Chia khoi hoan tat!")
print("[NEXT] Chay: python3 step3_matrix.py")
