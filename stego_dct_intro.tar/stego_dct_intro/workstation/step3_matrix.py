#!/usr/bin/env python3
import numpy as np

print("=" * 55)
print("  BUOC 3: BANG LUONG TU Q50 VA ZIGZAG SCAN")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.int32)

print("\n  Bang luong tu Q50 (JPEG standard):")
print("  (Gia tri nho = giu nhieu chi tiet = tan so thap)")
print("  (Gia tri lon = mat nhieu chi tiet = tan so cao)")
print("")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:5d}".format(Q50[i, j])
    print(row)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

print("\n  Thu tu Zigzag scan (64 vi tri, index 0-63):")
print("  [0..4]  = Tan so thap (DC va AC thap) - KHONG giau tin")
print("  [5..30] = Tan so trung binh          - VUNG GIAU TIN")
print("  [31..63]= Tan so cao                  - KHONG giau tin")
print("")
print("  10 vi tri dau tien trong zigzag:")
for k in range(10):
    r, c = ZIGZAG[k]
    q_val = Q50[r, c]
    zone = "DC" if k == 0 else ("tan so thap" if k < 5 else "MID-FREQ -> GIAU TIN")
    print("    Index {:2d}: vi tri ({},{}) | Q50={:3d} | {}".format(k, r, c, q_val, zone))

print("")
print("  Vung giau tin (index 5-30) dung Q50 trung binh:")
mid_q = [Q50[ZIGZAG[i][0], ZIGZAG[i][1]] for i in range(5, 30)]
print("    Q50 trung binh vung mid: {:.1f}".format(float(np.mean(mid_q))))
print("    Q50 min: {}  Q50 max: {}".format(min(mid_q), max(mid_q)))
print("")
print("[OK] Quan sat Q50 va zigzag hoan tat!")
print("[NEXT] Chay: python3 step4_dct.py")
