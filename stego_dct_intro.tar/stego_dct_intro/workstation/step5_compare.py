#!/usr/bin/env python3
"""
Buoc 5: So sanh anh truoc va sau khi nhu tin bang DCT
Thuc hien embed mot thong diep ngan roi so sanh PSNR, pixel thay doi
"""
import numpy as np
from PIL import Image
import math, os

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N = 8
    out = np.zeros((N, N), dtype=np.float64)
    for u in range(N):
        for v in range(N):
            cu = 1.0/math.sqrt(2) if u == 0 else 1.0
            cv = 1.0/math.sqrt(2) if v == 0 else 1.0
            s = 0.0
            for j in range(N):
                for k in range(N):
                    s += block[j,k] * math.cos((2*j+1)*u*math.pi/16) * math.cos((2*k+1)*v*math.pi/16)
            out[u,v] = 0.25*cu*cv*s
    return out

def idct2d(block):
    N = 8
    out = np.zeros((N, N), dtype=np.float64)
    for j in range(N):
        for k in range(N):
            s = 0.0
            for u in range(N):
                for v in range(N):
                    cu = 1.0/math.sqrt(2) if u == 0 else 1.0
                    cv = 1.0/math.sqrt(2) if v == 0 else 1.0
                    s += cu*cv*block[u,v] * math.cos((2*j+1)*u*math.pi/16) * math.cos((2*k+1)*v*math.pi/16)
            out[j,k] = 0.25*s
    return out

def str_to_bits(s):
    bits = []
    for c in s:
        b = ord(c)
        for i in range(7,-1,-1):
            bits.append((b>>i)&1)
    return bits

def embed_and_compare(img_path, message):
    img = Image.open(img_path).convert('L')
    arr = np.array(img, dtype=np.float64)
    H, W = arr.shape

    msg_bits = str_to_bits(message)
    length = len(msg_bits)
    header = [(length>>(31-i))&1 for i in range(32)]
    all_bits = header + msg_bits

    bit_idx = 0
    stego = arr.copy()
    bits_embedded = 0
    blocks_used = 0

    for bi in range(H//8):
        for bj in range(W//8):
            if bit_idx >= len(all_bits):
                break
            r0, c0 = bi*8, bj*8
            block = arr[r0:r0+8, c0:c0+8] - 128.0
            dct_b = dct2d(block)
            q = np.round(dct_b / Q50).astype(np.int32)
            changed_in_block = 0
            for (r,c) in ZIGZAG[5:31]:
                if bit_idx >= len(all_bits):
                    break
                if q[r,c] == 0:
                    continue
                bit = all_bits[bit_idx]
                if q[r,c] > 0:
                    q[r,c] = (q[r,c] & ~1) | bit
                else:
                    q[r,c] = -((-q[r,c] & ~1) | bit)
                bit_idx += 1
                bits_embedded += 1
                changed_in_block += 1
            if changed_in_block > 0:
                blocks_used += 1
            dq = q.astype(np.float64) * Q50
            rec = idct2d(dq) + 128.0
            stego[r0:r0+8, c0:c0+8] = np.clip(np.round(rec), 0, 255)

    os.makedirs('output', exist_ok=True)
    Image.fromarray(stego.astype(np.uint8), 'L').save('output/stego_intro.png')

    # Tinh toan chi so
    diff = np.abs(arr - stego)
    mse = np.mean((arr - stego) ** 2)
    psnr = 10 * math.log10(255**2 / mse) if mse > 0 else float('inf')
    changed_pixels = int((diff > 0).sum())
    total_pixels = H * W

    print("=" * 58)
    print("  BUOC 5: SO SANH ANH TRUOC VA SAU KHI GIAU TIN")
    print("=" * 58)
    print("\n  [THONG DIEP GIAU]")
    print("  Noi dung  : '{}'".format(message))
    print("  Do dai    : {} ky tu = {} bits".format(len(message), len(message)*8))
    print("  Payload   : {} bits (32-bit header + {} bits data)".format(len(all_bits), len(msg_bits)))
    print("  Bits da giau thanh cong: {}".format(bits_embedded))
    print("  So khoi 8x8 su dung    : {}".format(blocks_used))

    print("\n  [SO SANH ANH GOC vs ANH STEGO]")
    print("  Kich thuoc anh          : {} x {}".format(W, H))
    print("  Tong so pixel           : {}".format(total_pixels))
    print("  Pixel bi thay doi       : {} ({:.2f}%)".format(changed_pixels, changed_pixels*100.0/total_pixels))
    print("  Thay doi pixel lon nhat : {:.0f}".format(diff.max()))
    print("  Thay doi pixel TB       : {:.4f}".format(diff.mean()))
    print("  MSE (Mean Squared Error): {:.6f}".format(mse))
    print("  PSNR                    : {:.2f} dB".format(psnr))

    if psnr >= 40:
        danh_gia = "XUAT SAC - Mat nguoi khong phat hien duoc"
    elif psnr >= 35:
        danh_gia = "TOT - Kho phat hien bang mat thuong"
    elif psnr >= 30:
        danh_gia = "TRUNG BINH - Co the thay su khac biet nhe"
    else:
        danh_gia = "KEM - De bi phat hien"
    print("  Danh gia chat luong     : {}".format(danh_gia))

    print("\n  [SO SANH PIXEL TAI KHOI 8x8 DAU TIEN]")
    orig_block = arr[0:8, 0:8].astype(int)
    stego_block = stego[0:8, 0:8].astype(int)
    diff_block = np.abs(orig_block - stego_block)
    print("  Pixel goc (8x8):")
    for i in range(8):
        row = "    "
        for j in range(8):
            row += "{:4d}".format(orig_block[i,j])
        print(row)
    print("  Pixel stego (8x8):")
    for i in range(8):
        row = "    "
        for j in range(8):
            row += "{:4d}".format(stego_block[i,j])
        print(row)
    print("  Sai so tuyet doi (diff):")
    for i in range(8):
        row = "    "
        for j in range(8):
            row += "{:4d}".format(diff_block[i,j])
        print(row)

    print("\n  [PHAN TICH HE SO DCT - KHOI DAU TIEN]")
    block_c = arr[0:8, 0:8] - 128.0
    block_s = stego[0:8, 0:8] - 128.0
    dct_c = dct2d(block_c)
    dct_s = dct2d(block_s)
    q_c = np.round(dct_c / Q50).astype(np.int32)
    q_s = np.round(dct_s / Q50).astype(np.int32)
    print("  He so DCT luong tu hoa - ANH GOC (zigzag 0-15):")
    vals_c = [q_c[ZIGZAG[i][0], ZIGZAG[i][1]] for i in range(16)]
    print("    " + " ".join("{:4d}".format(v) for v in vals_c))
    print("  He so DCT luong tu hoa - ANH STEGO (zigzag 0-15):")
    vals_s = [q_s[ZIGZAG[i][0], ZIGZAG[i][1]] for i in range(16)]
    print("    " + " ".join("{:4d}".format(v) for v in vals_s))
    print("  LSB thay doi tai vi tri mid-freq (index 5-15):")
    for i in range(5, 16):
        vc = vals_c[i]
        vs = vals_s[i]
        mark = "<-- THAY DOI" if vc != vs else ""
        print("    Index {:2d}: goc={:4d} stego={:4d} {}".format(i, vc, vs, mark))

    print("\n  [ANH DA LUU] output/stego_intro.png")
    print("\n[OK] So sanh hoan tat. Lab nay da giup ban hieu:")
    print("  1. DCT bien doi pixel thanh he so tan so")
    print("  2. Giau tin chi thay doi 1 bit (LSB) cua he so mid-freq")
    print("  3. PSNR >= 40dB = anh stego trong giong het anh goc")
    print("  4. Chi co khoi co tin moi bi thay doi pixel")
    print("\n[XONG] Chay stoplab de hoan thanh lab!")

if __name__ == '__main__':
    if not os.path.exists('cover.png'):
        print("[LOI] Chua co cover.png. Chay gen_cover.py truoc!")
        exit(1)
    embed_and_compare('cover.png', 'PTIT_DCT_Intro')
