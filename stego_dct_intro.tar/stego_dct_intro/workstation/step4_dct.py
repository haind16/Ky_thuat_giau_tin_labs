#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, os

Q50 = np.array([
    [16,11,10,16,24,40,51,61],
    [12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],
    [14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],
    [24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],
    [72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N = 8
    out = np.zeros((N, N), dtype=np.float64)
    for u in range(N):
        for v in range(N):
            cu = 1.0/math.sqrt(2) if u == 0 else 1.0
            cv = 1.0/math.sqrt(2) if v == 0 else 1.0
            s = 0.0
            for j in range(N):
                for k in range(N):
                    s += block[j,k] * math.cos((2*j+1)*u*math.pi/16) * math.cos((2*k+1)*v*math.pi/16)
            out[u,v] = 0.25 * cu * cv * s
    return out

def idct2d(block):
    N = 8
    out = np.zeros((N, N), dtype=np.float64)
    for j in range(N):
        for k in range(N):
            s = 0.0
            for u in range(N):
                for v in range(N):
                    cu = 1.0/math.sqrt(2) if u == 0 else 1.0
                    cv = 1.0/math.sqrt(2) if v == 0 else 1.0
                    s += cu * cv * block[u,v] * math.cos((2*j+1)*u*math.pi/16) * math.cos((2*k+1)*v*math.pi/16)
            out[j,k] = 0.25 * s
    return out

if not os.path.exists('cover.png'):
    print("[LOI] Chua co cover.png!")
    exit(1)

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)

print("=" * 55)
print("  BUOC 4: THUC HIEN DCT VA LUONG TU HOA")
print("=" * 55)

# Lay khoi 8x8 dau tien
block_orig = arr[0:8, 0:8]
block_shifted = block_orig - 128.0

print("\n  [A] Khoi 8x8 pixel goc (row=0, col=0):")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:6.1f}".format(block_orig[i,j])
    print(row)

dct_block = dct2d(block_shifted)
print("\n  [B] Sau DCT 2D (64 he so tan so):")
print("      Goc trai tren = F(0,0) = DC component (gia tri trung binh)")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:8.2f}".format(dct_block[i,j])
    print(row)

q_block = np.round(dct_block / Q50).astype(np.int32)
print("\n  [C] Sau luong tu hoa (chia cho Q50, lam tron):")
print("      He so nho = giu it thong tin; he so = 0 se bo qua khi giau tin")
for i in range(8):
    row = "    "
    for j in range(8):
        row += "{:5d}".format(q_block[i,j])
    print(row)

print("\n  [D] He so theo thu tu Zigzag scan:")
print("      (index 0=DC, index 5-30=vung giau tin)")
zigzag_vals = []
for idx, (r, c) in enumerate(ZIGZAG):
    zigzag_vals.append(q_block[r, c])

# In 32 he so dau
print("      Index  0-15:", " ".join("{:4d}".format(v) for v in zigzag_vals[0:16]))
print("      Index 16-31:", " ".join("{:4d}".format(v) for v in zigzag_vals[16:32]))

nonzero_mid = sum(1 for v in zigzag_vals[5:31] if v != 0)
print("\n  [E] Thong ke vung mid-frequency (index 5-30):")
print("      Tong he so  : 26")
print("      He so != 0  : {} (co the giau tin vao day)".format(nonzero_mid))
print("      He so == 0  : {} (bo qua)".format(26 - nonzero_mid))
print("      Cac he so: {}".format(zigzag_vals[5:31]))

# IDCT de kiem tra phuc hoi
dq = q_block.astype(np.float64) * Q50
restored = idct2d(dq) + 128.0
restored_clipped = np.clip(np.round(restored), 0, 255)
err = np.abs(block_orig - restored_clipped)
print("\n  [F] Sau IDCT (phuc hoi ve mien khong gian):")
print("      Sai so trung binh luong tu hoa: {:.4f}".format(float(err.mean())))
print("      Sai so max: {:.1f}".format(float(err.max())))
print("      (Sai so nay la do luong tu hoa - JPEG nen mat thong tin day!)")

print("\n  [TOM TAT PIPELINE DCT]")
print("  Pixel -> Tru 128 -> DCT -> Chia Q50 -> [giau tin vao mid-freq]")
print("                                       -> Nhan Q50 -> IDCT -> Cong 128 -> Pixel")
print("\n[OK] Hoan tat buoc 4. Da hieu nguyen ly DCT!")
print("[NEXT] Chay: python3 step5_compare.py")
