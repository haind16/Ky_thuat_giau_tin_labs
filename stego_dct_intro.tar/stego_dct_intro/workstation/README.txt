=== LAB 1: GIOI THIEU DCT - QUAN SAT VA PHAN TICH ===
Muc tieu: Hieu nguyen ly bien doi DCT va nen tang giau tin
QUY TRINH:
  Buoc 0: python3 gen_cover.py - Tao anh test
  Buoc 1: python3 step1_view.py      - Quan sat anh goc
  Buoc 2: python3 step2_grayscale.py - Grayscale, chia khoi 8x8
  Buoc 3: python3 step3_matrix.py    - Xem Q50 va zigzag scan
  Buoc 4: python3 step4_dct.py       - Thuc hien DCT, luong tu hoa
  Buoc 5: python3 step5_compare.py   - So sanh anh goc vs anh stego
Khi xong: stoplab
