#!/usr/bin/env python3
"""Tao anh cover.png 256x256 grayscale"""
import numpy as np
from PIL import Image
import math

arr = np.zeros((256, 256), dtype=np.uint8)
for i in range(256):
    for j in range(256):
        val = int(
            128
            + 50 * math.sin(2 * math.pi * i / 32)
            + 30 * math.cos(2 * math.pi * j / 16)
            + 20 * math.sin(2 * math.pi * (i + j) / 48)
        ) % 256
        arr[i, j] = val
Image.fromarray(arr, 'L').save('cover.png')
print("[OK] Da tao cover.png (256x256 grayscale)")
