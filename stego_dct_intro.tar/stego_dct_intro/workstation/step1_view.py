#!/usr/bin/env python3
import numpy as np
from PIL import Image
import os

if not os.path.exists('cover.png'):
    print("[LOI] Chua co cover.png. Chay gen_cover.py truoc!")
    exit(1)

img = Image.open('cover.png').convert('L')
arr = np.array(img)
H, W = arr.shape

print("=" * 48)
print("  BUOC 1: QUAN SAT ANH GOC")
print("=" * 48)
print("  Ten file         : cover.png")
print("  Kich thuoc       : {} x {}".format(W, H))
print("  Mode             : Grayscale (8-bit)")
print("  Tong so pixel    : {}".format(W * H))
print("  Gia tri min      : {}".format(int(arr.min())))
print("  Gia tri max      : {}".format(int(arr.max())))
print("  Trung binh       : {:.2f}".format(float(arr.mean())))
print("")
print("  Goc trai tren 4x4 pixel dau tien:")
for i in range(4):
    row = "    "
    for j in range(4):
        row += "{:4d}".format(int(arr[i, j]))
    print(row)
print("")
print("[OK] Quan sat anh goc hoan tat!")
print("[NEXT] Chay: python3 step2_grayscale.py")
