#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

# Ma tran DCT chuan
_j   = np.arange(8, dtype=np.float64)
_COS = np.cos(np.outer(2*_j+1, _j) * math.pi / 16)
_C   = np.ones(8); _C[0] = 1.0/math.sqrt(2)
_CC  = np.outer(_C, _C)
def dct2d(b):
    return 0.25 * _CC * (_COS.T @ b.astype(np.float64) @ _COS)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct_entropy(block):
    """Entropy Shannon cua he so DCT luong tu hoa (AC) trong 1 block 8x8"""
    F = dct2d(block - 128.0)
    q = np.rint(F / Q50).astype(int).flatten()[1:]  # bo DC
    counts = {}
    for v in q:
        counts[v] = counts.get(v, 0) + 1
    total = len(q)
    ent = 0.0
    for c in counts.values():
        p = c / total
        if p > 0:
            ent -= p * math.log2(p)
    return ent

img_path  = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path  = sys.argv[2] if len(sys.argv) > 2 else 'entropy_map.txt'
heat_path = sys.argv[3] if len(sys.argv) > 3 else 'heatmap.png'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape
BH, BW = H//8, W//8

# Tinh entropy DCT cho tung block 8x8
emap = np.zeros((BH, BW))
for bi in range(BH):
    for bj in range(BW):
        emap[bi, bj] = dct_entropy(img[bi*8:bi*8+8, bj*8:bj*8+8])

emin, emax, emean = emap.min(), emap.max(), emap.mean()
estd = emap.std()

# Block co entropy DCT thap => nhieu he so AC = 0 sau luong tu hoa
# => bi nen manh (double compress) hoac co it bien dong tan so
threshold = emean - 1.5 * estd
anomaly_blocks = []
for bi in range(BH):
    for bj in range(BW):
        if emap[bi, bj] < threshold:
            anomaly_blocks.append({
                'block': [bi, bj],
                'dct_entropy': round(float(emap[bi, bj]), 4),
                'region': 'top_left' if (bi < BH//2 and bj < BW//2) else 'other'
            })

# Heatmap: mau sang = entropy cao (nhieu bien dong DCT), mau toi = entropy thap (nghi van)
norm = ((emap - emin) / (emax - emin + 1e-9) * 255).astype(np.uint8)
hmap = Image.fromarray(norm, 'L').resize((W, H), Image.NEAREST)
hmap.save(heat_path)

result = {
    'file': img_path,
    'analysis': 'DCT quantized coefficient entropy per 8x8 block',
    'entropy_min': round(float(emin), 4),
    'entropy_max': round(float(emax), 4),
    'entropy_mean': round(float(emean), 4),
    'entropy_std': round(float(estd), 4),
    'anomaly_threshold': round(float(threshold), 4),
    'anomaly_blocks': anomaly_blocks[:20],
    'anomaly_count': len(anomaly_blocks)
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("DCT entropy map: min={:.3f} max={:.3f} mean={:.3f} std={:.3f} | anomaly_blocks={} | saved -> {}".format(
    emin, emax, emean, estd, len(anomaly_blocks), out_path))
print("Heatmap -> {} (toi=entropy DCT thap=nghi van double-compress hoac LSB tampering)".format(heat_path))
if anomaly_blocks:
    print("Top anomaly blocks (entropy DCT thap nhat):")
    for ab in anomaly_blocks[:5]:
        print("  block {} | dct_entropy={:.4f} | region={}".format(
            ab['block'], ab['dct_entropy'], ab['region']))
