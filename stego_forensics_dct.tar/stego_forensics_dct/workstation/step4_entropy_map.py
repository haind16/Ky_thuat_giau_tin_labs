#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

def block_entropy(block):
    flat = block.flatten().astype(int)
    counts = {}
    for v in flat:
        counts[v] = counts.get(v, 0) + 1
    total = len(flat)
    ent = 0.0
    for c in counts.values():
        p = c / total
        if p > 0:
            ent -= p * math.log2(p)
    return ent

img_path  = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path  = sys.argv[2] if len(sys.argv) > 2 else 'entropy_map.txt'
heat_path = sys.argv[3] if len(sys.argv) > 3 else 'heatmap.png'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape
BH, BW = H//8, W//8

emap = np.zeros((BH, BW))
for bi in range(BH):
    for bj in range(BW):
        emap[bi,bj] = block_entropy(img[bi*8:bi*8+8, bj*8:bj*8+8])

emin, emax, emean = emap.min(), emap.max(), emap.mean()

# Detect anomaly blocks (entropy significantly below mean — over-compressed)
threshold = emean - 1.5 * emap.std()
anomaly_blocks = []
for bi in range(BH):
    for bj in range(BW):
        if emap[bi,bj] < threshold:
            anomaly_blocks.append({'block': [bi,bj], 'entropy': round(float(emap[bi,bj]),4)})

# Save heatmap as PNG
norm = ((emap - emin) / (emax - emin + 1e-9) * 255).astype(np.uint8)
hmap = Image.fromarray(norm, 'L').resize((W, H), Image.NEAREST)
hmap.save(heat_path)

result = {
    'file': img_path,
    'entropy_min': round(float(emin),4),
    'entropy_max': round(float(emax),4),
    'entropy_mean': round(float(emean),4),
    'anomaly_threshold': round(float(threshold),4),
    'anomaly_blocks': anomaly_blocks[:20],
    'anomaly_count': len(anomaly_blocks)
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("entropy map: min={:.3f} max={:.3f} mean={:.3f} | anomaly_blocks={} | saved -> {}".format(
    emin, emax, emean, len(anomaly_blocks), out_path))
print("Heatmap saved -> {} (dark=low entropy = suspicious)".format(heat_path))
if anomaly_blocks:
    print("Top anomaly blocks:")
    for ab in anomaly_blocks[:5]:
        print("  block {} entropy={:.4f}".format(ab['block'], ab['entropy']))
