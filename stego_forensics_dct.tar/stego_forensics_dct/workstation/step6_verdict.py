#!/usr/bin/env python3
import sys, json

meta_path   = sys.argv[1] if len(sys.argv) > 1 else 'metadata_report.txt'
dct_path    = sys.argv[2] if len(sys.argv) > 2 else 'dct_report.txt'
recomp_path = sys.argv[3] if len(sys.argv) > 3 else 'recomp_report.txt'
out_path    = sys.argv[4] if len(sys.argv) > 4 else 'verdict.txt'

findings = []
confidence = 0

try:
    with open(dct_path) as f:
        dct = json.load(f)
    chi = dct.get('chi_square', 0)
    if dct.get('suspicious'):
        findings.append("Chi-square DCT = {:.4f} vuot nguong cho phep => co dau hieu giau tin".format(chi))
        confidence += 35
    else:
        findings.append("Chi-square DCT = {:.4f} trong nguong binh thuong".format(chi))

    asym = [k for k, v in dct.get('pairs', {}).items() if not v.get('symmetry_ok', True)]
    if asym:
        findings.append("Cap he so DCT mat doi xung tai k={} => histogram bi can thiep".format(asym))
        confidence += 20
except Exception as e:
    findings.append("Khong doc duoc ket qua phan tich DCT: {}".format(e))

try:
    with open(recomp_path) as f:
        rc = json.load(f)
    if rc.get('double_compression_detected'):
        findings.append("Phat hien NEN KEP (double compression): goc trai tren dung bang luong hoa khac")
        confidence += 30
        ra = rc.get('region_analysis', {})
        findings.append("He so khac 0 vung nghi van vs phan con lai: diff = {:.4f}".format(ra.get('difference', 0)))
    dips = rc.get('histogram_dips', [])
    if dips:
        findings.append("Co {} dip trong histogram he so DCT => dau hieu dac trung cua double-JPEG".format(len(dips)))
        confidence += 15
except Exception as e:
    findings.append("Khong doc duoc ket qua phan tich nen: {}".format(e))

score = min(confidence, 100)
if score >= 70:
    verdict_label = "DO TIN CAY CAO — Anh da bi chinh sua va co kha nang chua payload an"
elif score >= 40:
    verdict_label = "DO TIN CAY TRUNG BINH — Phat hien bat thuong, can dieu tra them"
else:
    verdict_label = "DO TIN CAY THAP — Chua co bang chung ro rang ve gia mao"

report = [
    "=" * 60,
    "BAO CAO DIEU TRA PHAP Y ANH SO",
    "=" * 60,
    "",
    "KET LUAN: {}".format(verdict_label),
    "DO TIN CAY: {}%".format(score),
    "",
    "BANG CHUNG THU THAP:",
]
for i, f in enumerate(findings, 1):
    report.append("  {}. {}".format(i, f))

report += [
    "",
    "VUNG NGHI VAN:",
    "  - Goc trai tren: bi nen lai bang bang luong hoa chat luong khac (double compress)",
    "  - Dai tan so trung (mid-frequency DCT): co dau hieu thay doi LSB de giau tin",
    "",
    "BUOC TIEP THEO:",
    "  Chay step7_extract.py voi key 'ForensicKey2026' de phuc hoi payload an",
    "  Vi du: python3 step7_extract.py press_release.jpg ForensicKey2026 recovered.txt",
    "=" * 60,
]

text = "\n".join(report)
with open(out_path, 'w') as f:
    f.write(text + "\n")

print("VERDICT: {} | do_tin_cay={}%".format(verdict_label, score))
print("Saved -> {}".format(out_path))
