#!/usr/bin/env python3
import numpy as np
from PIL import Image
import sys, json, hashlib

def lcg(s): return (1664525*s+1013904223) % (2**32)

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
key      = sys.argv[2] if len(sys.argv) > 2 else 'ForensicKey2026'
out_path = sys.argv[3] if len(sys.argv) > 3 else 'recovered.txt'

pixels = np.array(Image.open(img_path).convert('L'), dtype=np.uint8)
H, W = pixels.shape

# Tao lai danh sach pixel va shuffle voi cung PRNG + key
all_pixels = [(i, j) for i in range(H) for j in range(W)]
seed_int = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
state = seed_int
order = list(range(len(all_pixels)))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

# Doc 32 bit header (bo qua pixel bien, cung dieu kien voi luc nhung)
header_bits = []
order_idx = 0
while order_idx < len(order) and len(header_bits) < 32:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_pixels[pos_idx]
    val = int(pixels[pi, pj])
    if val < 4 or val > 251: continue
    header_bits.append(val & 1)

if len(header_bits) < 32:
    print("Loi: khong du bit de doc header")
    sys.exit(1)

n_bits = 0
for b in header_bits:
    n_bits = (n_bits << 1) | b

if n_bits <= 0 or n_bits > 8000:
    print("Loi: header khong hop le (n_bits={}) — sai key".format(n_bits))
    sys.exit(1)

# Doc payload
payload_bits = []
while order_idx < len(order) and len(payload_bits) < n_bits:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_pixels[pos_idx]
    val = int(pixels[pi, pj])
    if val < 4 or val > 251: continue
    payload_bits.append(val & 1)

# Giai ma thanh chuoi ky tu
chars = []
for i in range(0, len(payload_bits)-7, 8):
    byte = 0
    for b in payload_bits[i:i+8]:
        byte = (byte << 1) | b
    chars.append(chr(byte) if 32 <= byte <= 126 else '?')

message = ''.join(chars)

result = {
    "image": img_path,
    "key_used": key,
    "key_hash": hashlib.sha256(key.encode()).hexdigest()[:16],
    "payload_bits_expected": n_bits,
    "payload_bits_read": len(payload_bits),
    "recovered_chars": len(chars),
    "message": message
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("Key: '{}' | payload = {} bits = {} ky tu".format(key, n_bits, len(chars)))
print("THONG DIEP PHUC HOI: {}".format(message))
print("Saved -> {}".format(out_path))
