#!/usr/bin/env python3
import jpegio as jio
import numpy as np
import sys, json, hashlib

def lcg(s): return (1664525*s+1013904223)%(2**32)

ZIGZAG_AC=[(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
           (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
           (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
           (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]
REP=3

img_path=sys.argv[1] if len(sys.argv)>1 else 'press_release.jpg'
key     =sys.argv[2] if len(sys.argv)>2 else 'ForensicKey2026'
out_path=sys.argv[3] if len(sys.argv)>3 else 'recovered.txt'

# Doc he so DCT truc tiep tu file JPEG (khong qua pixel)
jpg=jio.read(img_path)
coeffs=jpg.coef_arrays[0]
CH,CW=coeffs.shape

# Thu thap vi tri AC |val|>=2 theo cung thu tu voi luc nhung
positions=[]
for bi in range(CH//8):
    for bj in range(CW//8):
        for (r,c) in ZIGZAG_AC:
            pi,pj=bi*8+r, bj*8+c
            if abs(int(coeffs[pi,pj]))>=2:
                positions.append((pi,pj))

# Shuffle voi cung PRNG va key
seed_int=int(hashlib.sha256(key.encode()).hexdigest(),16)%(2**31)
state=seed_int; order=list(range(len(positions)))
for i in range(len(order)-1,0,-1):
    state=lcg(state); j=state%(i+1); order[i],order[j]=order[j],order[i]

def read_bits_rep(n_raw):
    bits=[]; idx=0
    for pos_idx in order:
        if len(bits)>=n_raw: break
        pi,pj=positions[pos_idx]
        val=int(coeffs[pi,pj])
        bits.append(val&1 if val>0 else (-val)&1)
    return bits

def majority(bits_rep):
    out=[]
    for i in range(0,len(bits_rep)-REP+1,REP):
        g=bits_rep[i:i+REP]
        out.append(1 if sum(g)>REP//2 else 0)
    return out

# Doc 32 bit header voi rep code
raw_header=read_bits_rep(32*REP)
if len(raw_header)<32*REP:
    print("Loi: khong du bit header"); sys.exit(1)

header_bits=majority(raw_header)
n_bits=0
for b in header_bits: n_bits=(n_bits<<1)|b

if n_bits<=0 or n_bits>8000:
    print("Loi: header khong hop le (n_bits={}) — sai key".format(n_bits)); sys.exit(1)

# Doc payload
all_raw=read_bits_rep(32*REP+n_bits*REP)
payload_bits=majority(all_raw[32*REP:])

chars=[]
for i in range(0,len(payload_bits)-7,8):
    byte=0
    for b in payload_bits[i:i+8]: byte=(byte<<1)|b
    chars.append(chr(byte) if 32<=byte<=126 else '?')
message=''.join(chars)

result={"image":img_path,"key_used":key,
        "key_hash":hashlib.sha256(key.encode()).hexdigest()[:16],
        "format":"JPEG_DCT_domain","rep_code":REP,
        "payload_bits_expected":n_bits,"payload_bits_read":len(payload_bits),
        "recovered_chars":len(chars),"message":message}
with open(out_path,'w') as f: json.dump(result,f,indent=2)

print("Key: '{}' | JPEG DCT domain | {}x rep code | payload={} bits = {} ky tu".format(
    key,REP,n_bits,len(chars)))
print("THONG DIEP PHUC HOI: {}".format(message))
print("Saved -> {}".format(out_path))
