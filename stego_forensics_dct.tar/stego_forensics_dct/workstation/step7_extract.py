#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json, hashlib

Q50 = np.array([[16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]], dtype=np.float64)

_j=np.arange(8,dtype=np.float64)
_COS=np.cos(np.outer(2*_j+1,_j)*math.pi/16)
_C=np.ones(8); _C[0]=1/math.sqrt(2); _CC=np.outer(_C,_C)
dct2d = lambda b: 0.25*_CC*(_COS.T@b.astype(np.float64)@_COS)
def lcg(s): return (1664525*s+1013904223)%(2**32)

ZIGZAG_AC=[(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
           (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
           (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
           (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]

REP = 3
img_path = sys.argv[1] if len(sys.argv)>1 else 'press_release.png'
key      = sys.argv[2] if len(sys.argv)>2 else 'ForensicKey2026'
out_path = sys.argv[3] if len(sys.argv)>3 else 'recovered.txt'

img=np.array(Image.open(img_path).convert('L'),dtype=np.float64)
H,W=img.shape

coeff_cache={}
for bi in range(H//8):
    for bj in range(W//8):
        q=np.rint(dct2d(img[bi*8:bi*8+8,bj*8:bj*8+8]-128)/Q50).astype(int)
        coeff_cache[(bi,bj)]=q.copy()

all_pos=[(bi,bj,r,c) for bi in range(H//8) for bj in range(W//8) for (r,c) in ZIGZAG_AC]
seed_int=int(hashlib.sha256(key.encode()).hexdigest(),16)%(2**31)
state=seed_int; order=list(range(len(all_pos)))
for i in range(len(order)-1,0,-1):
    state=lcg(state); j=state%(i+1); order[i],order[j]=order[j],order[i]

def read_bits(n_raw):
    bits=[]; idx=0
    for pos_idx in order:
        if len(bits)>=n_raw: break
        bi,bj,r,c=all_pos[pos_idx]
        q_val=int(coeff_cache[(bi,bj)][r,c])
        if abs(q_val)<2: continue
        bits.append(q_val&1 if q_val>0 else (-q_val)&1)
    return bits

def majority(bits_rep):
    out=[]
    for i in range(0,len(bits_rep)-REP+1,REP):
        group=bits_rep[i:i+REP]
        out.append(1 if sum(group)>REP//2 else 0)
    return out

raw_header=read_bits(32*REP)
if len(raw_header)<32*REP:
    print("Loi: khong du bit header"); sys.exit(1)

header_bits=majority(raw_header)
n_bits=0
for b in header_bits: n_bits=(n_bits<<1)|b

if n_bits<=0 or n_bits>8000:
    print("Loi: header khong hop le (n_bits={}) — sai key".format(n_bits)); sys.exit(1)

all_raw=read_bits(32*REP + n_bits*REP)
raw_payload=all_raw[32*REP:]
payload_bits=majority(raw_payload)

chars=[]
for i in range(0,len(payload_bits)-7,8):
    byte=0
    for b in payload_bits[i:i+8]: byte=(byte<<1)|b
    chars.append(chr(byte) if 32<=byte<=126 else '?')

message=''.join(chars)
result={"image":img_path,"key_used":key,
        "key_hash":hashlib.sha256(key.encode()).hexdigest()[:16],
        "rep_code":REP,"payload_bits_expected":n_bits,
        "payload_bits_read":len(payload_bits),
        "recovered_chars":len(chars),"message":message}

with open(out_path,'w') as f: json.dump(result,f,indent=2)
print("Key: '{}' | DCT-domain {}x rep code | payload={} bits = {} ky tu".format(key,REP,n_bits,len(chars)))
print("THONG DIEP PHUC HOI: {}".format(message))
print("Saved -> {}".format(out_path))
