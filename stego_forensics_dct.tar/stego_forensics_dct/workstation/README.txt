=== LAB: DIGITAL IMAGE FORENSICS – DCT INVESTIGATION ===

TINH HUONG:
Anh 'press_release.png' bi nghi ngo chinh sua
va chua du lieu bi mat. Nhiem vu: dieu tra anh.

B0: Thu thap evidence
  file press_release.png
  exiftool press_release.png > metadata_report.txt
  strings press_release.png | head -40
  xxd press_release.png | head -8
  sha256sum press_release.png > evidence_hash.txt
  cat metadata_report.txt

B1: Phan tich cau truc file
  python3 step1_jpeg_struct.py press_release.png jpeg_struct.txt
  cat jpeg_struct.txt

B2: Kiem tra quantization
  python3 step2_qtable.py press_release.png qtable_dump.txt
  cat qtable_dump.txt

B3: Phan tich DCT + chi-square
  python3 step3_dct_analysis.py press_release.png dct_report.txt
  cat dct_report.txt

B4: Tao entropy heatmap
  python3 step4_entropy_map.py press_release.png entropy_map.txt heatmap.png
  eog heatmap.png &
  cat entropy_map.txt

B5: Phat hien double compression
  python3 step5_recompression.py press_release.png recomp_report.txt
  cat recomp_report.txt

B6: Tao bao cao forensic
  python3 step6_verdict.py metadata_report.txt dct_report.txt recomp_report.txt verdict.txt
  cat verdict.txt

B7: Phuc hoi payload an
  python3 step7_extract.py press_release.png ForensicKey2026 recovered.txt
  cat recovered.txt

KIEM TRA:
  md5sum press_release.png evidence_hash.txt

XONG:
  stoplab
