#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(b):
    N=8; out=np.zeros((N,N))
    for u in range(8):
        for v in range(8):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(8) for k in range(8))
    return out

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'recomp_report.txt'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape

# Double compression fingerprint: recompress and compare DCT coefficient distributions
# Single-compressed: coefficients cluster at multiples of quantization step
# Double-compressed: periodic dips in histogram at certain values

coeff_vals = []
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        for u in range(1,8):
            for v in range(1,8):
                coeff_vals.append(int(q[u,v]))

hist = {}
for v in coeff_vals:
    hist[v] = hist.get(v,0)+1

# Detect periodic dips — signature of double compression
dips = []
for k in range(2,12):
    h_k   = hist.get(k,0)
    h_km1 = hist.get(k-1,0)
    h_kp1 = hist.get(k+1,0)
    expected = (h_km1 + h_kp1) / 2.0
    if expected > 5 and h_k < expected * 0.6:
        dips.append({'value': k, 'count': h_k, 'expected': round(expected,1), 'ratio': round(h_k/(expected+1e-9),3)})

# Region analysis: compare top-left vs rest
tl_coeffs = []; rest_coeffs = []
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        vals = [int(q[u,v]) for u in range(1,8) for v in range(1,8)]
        if bi < H//16 and bj < W//16:
            tl_coeffs.extend(vals)
        else:
            rest_coeffs.extend(vals)

tl_nonzero  = sum(1 for v in tl_coeffs if v!=0) / max(len(tl_coeffs),1)
rest_nonzero = sum(1 for v in rest_coeffs if v!=0) / max(len(rest_coeffs),1)

double_compression_detected = len(dips) >= 2 or abs(tl_nonzero - rest_nonzero) > 0.05

result = {
    'file': img_path,
    'double_compression_detected': double_compression_detected,
    'histogram_dips': dips,
    'region_analysis': {
        'top_left_nonzero_ratio': round(tl_nonzero,4),
        'rest_nonzero_ratio': round(rest_nonzero,4),
        'difference': round(abs(tl_nonzero-rest_nonzero),4)
    },
    'hist_sample': {str(k): hist.get(k,0) for k in range(-8,9)}
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("double_compression_detected={} | dips={} | saved -> {}".format(
    double_compression_detected, len(dips), out_path))
print("Region: top-left nonzero={:.3f} vs rest={:.3f} (diff={:.3f})".format(
    tl_nonzero, rest_nonzero, abs(tl_nonzero-rest_nonzero)))
if dips:
    print("Histogram dips (compression fingerprint):")
    for d in dips:
        print("  coeff={}: count={} expected={:.1f} ratio={:.3f}".format(
            d['value'], d['count'], d['expected'], d['ratio']))
