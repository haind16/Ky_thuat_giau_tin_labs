#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(b):
    N=8; out=np.zeros((N,N))
    for u in range(8):
        for v in range(8):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(8) for k in range(8))
    return out

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'dct_report.txt'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape

hist = {}
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        for u in range(8):
            for v in range(8):
                if u==0 and v==0: continue
                val = int(q[u,v])
                hist[val] = hist.get(val,0) + 1

# Chi-square on pairs
chi_sq = 0.0
pairs = {}
for k in range(1, 10):
    np_ = hist.get(k, 0)
    nn  = hist.get(-k, 0)
    expected = (np_ + nn) / 2.0
    if expected > 0:
        chi_sq += (np_ - expected)**2 / expected
        chi_sq += (nn  - expected)**2 / expected
    pairs[k] = {'pos': np_, 'neg': nn,
                'ratio': round(np_/(nn+1e-9), 4),
                'symmetry_ok': abs(np_-nn) < 0.15*(np_+nn+1)}

suspicious = chi_sq > 50

result = {
    'file': img_path,
    'chi_square': round(chi_sq, 4),
    'suspicious': suspicious,
    'histogram_range': {str(k): hist.get(k,0) for k in range(-10,11)},
    'pairs': {str(k): pairs[k] for k in range(1,10)}
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("chi_square={:.4f} | suspicious={} | saved -> {}".format(chi_sq, suspicious, out_path))
print("Pairs +k/-k symmetry:")
for k in range(1,6):
    p = pairs[k]
    flag = " <-- ASYMMETRIC" if not p['symmetry_ok'] else ""
    print("  k={}: +{}/-{}  ratio={:.3f}{}".format(k, p['pos'], p['neg'], p['ratio'], flag))
