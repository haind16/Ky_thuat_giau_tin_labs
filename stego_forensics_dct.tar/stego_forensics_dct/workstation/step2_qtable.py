#!/usr/bin/env python3
import sys, json, struct
import numpy as np
from PIL import Image

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'qtable_dump.txt'

with open(img_path, 'rb') as f:
    data = f.read()

is_png = data[:8] == b'\x89PNG\r\n\x1a\n'
tables = []
anomaly = False

if not is_png:
    Q50_ref = [16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,
               14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,
               18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,
               49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99]
    i = 0
    while i < len(data)-1:
        if data[i] == 0xFF and data[i+1] == 0xDB:
            length = struct.unpack('>H', data[i+2:i+4])[0]
            seg = data[i+4:i+2+length]
            j = 0
            while j < len(seg):
                precision = (seg[j] >> 4)
                table_id  = (seg[j] & 0x0F)
                j += 1
                if precision == 0:
                    vals = list(seg[j:j+64]); j += 64
                else:
                    if j + 128 > len(seg): break
                    vals = [struct.unpack('>H', seg[j+k*2:j+k*2+2])[0] for k in range(64)]
                    j += 128
                diff = sum(abs(vals[k]-Q50_ref[k]) for k in range(64))
                quality_est = max(1, min(100, round(100 - diff/30)))
                tables.append({'table_id': table_id, 'values': vals,
                               'diff_from_Q50': diff, 'estimated_quality': quality_est})
            i += 2 + length
        else:
            i += 1
    anomaly = len(tables) > 1 and abs(tables[0]['estimated_quality'] - tables[-1]['estimated_quality']) > 10
else:
    # PNG khong co quantization table — dung phan tich block variance thay the
    img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
    H, W = img.shape
    block_vars = []
    for bi in range(H//8):
        for bj in range(W//8):
            block_vars.append(float(np.var(img[bi*8:bi*8+8, bj*8:bj*8+8])))
    mean_var = float(np.mean(block_vars))
    std_var  = float(np.std(block_vars))

    tl_idx  = {bi*(W//8)+bj for bi in range(H//16) for bj in range(W//16)}
    tl_vars   = [block_vars[i] for i in range(len(block_vars)) if i in tl_idx]
    rest_vars = [block_vars[i] for i in range(len(block_vars)) if i not in tl_idx]
    tl_mean   = float(np.mean(tl_vars))   if tl_vars   else 0.0
    rest_mean = float(np.mean(rest_vars)) if rest_vars else 0.0
    region_diff = abs(tl_mean - rest_mean)
    anomaly = region_diff > mean_var * 0.3

    tables.append({
        'note': 'PNG khong co bang luong hoa — su dung block variance lam chi so thay the',
        'mean_block_variance': round(mean_var, 4),
        'std_block_variance':  round(std_var, 4),
        'top_left_mean_var':   round(tl_mean, 4),
        'rest_mean_var':       round(rest_mean, 4),
        'region_difference':   round(region_diff, 4),
        'anomaly_detected':    anomaly
    })

result = {
    'file': img_path,
    'format': 'PNG' if is_png else 'JPEG',
    'quantization_tables': len(tables),
    'tables': tables,
    'anomaly_detected': anomaly
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

if is_png:
    t = tables[0]
    print("quantization tables: N/A (PNG) | block variance analysis | anomaly={}".format(anomaly))
    print("  mean_var={:.2f} | tl_var={:.2f} | rest_var={:.2f} | diff={:.2f}".format(
        t['mean_block_variance'], t['top_left_mean_var'], t['rest_mean_var'], t['region_difference']))
else:
    print("quantization tables: {} | anomaly={}".format(len(tables), anomaly))
    for t in tables:
        print("  Table {}: est_quality=Q{} | diff_from_Q50={}".format(
            t['table_id'], t['estimated_quality'], t['diff_from_Q50']))
print("Saved -> {}".format(out_path))
