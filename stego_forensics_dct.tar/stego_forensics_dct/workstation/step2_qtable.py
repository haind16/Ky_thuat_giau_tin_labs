#!/usr/bin/env python3
import sys, json, struct
import numpy as np, math
from PIL import Image

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'qtable_dump.txt'

with open(img_path, 'rb') as f:
    data = f.read()

is_png = data[:8] == b'\x89PNG\r\n\x1a\n'
tables = []
anomaly = False

# Ma tran DCT chuan (numpy matrix multiply — chinh xac, khong sai so float)
_j   = np.arange(8, dtype=np.float64)
_COS = np.cos(np.outer(2*_j+1, _j) * math.pi / 16)
_C   = np.ones(8); _C[0] = 1.0/math.sqrt(2)
_CC  = np.outer(_C, _C)
def dct2d(b):
    return 0.25 * _CC * (_COS.T @ b.astype(np.float64) @ _COS)

Q50_ref = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

if not is_png:
    # JPEG: doc bang luong hoa tu file header
    Q50_flat = Q50_ref.flatten().tolist()
    i = 0
    while i < len(data)-1:
        if data[i] == 0xFF and data[i+1] == 0xDB:
            length = struct.unpack('>H', data[i+2:i+4])[0]
            seg = data[i+4:i+2+length]
            j = 0
            while j < len(seg):
                precision = (seg[j] >> 4); table_id = (seg[j] & 0x0F); j += 1
                if precision == 0:
                    vals = list(seg[j:j+64]); j += 64
                else:
                    if j + 128 > len(seg): break
                    vals = [struct.unpack('>H', seg[j+k*2:j+k*2+2])[0] for k in range(64)]; j += 128
                diff = sum(abs(vals[k]-Q50_flat[k]) for k in range(64))
                quality_est = max(1, min(100, round(100 - diff/30)))
                tables.append({'table_id': table_id, 'values': vals,
                               'diff_from_Q50': diff, 'estimated_quality': quality_est})
            i += 2 + length
        else:
            i += 1
    anomaly = len(tables) > 1 and abs(tables[0]['estimated_quality'] - tables[-1]['estimated_quality']) > 10

else:
    # PNG: khong co bang luong hoa luu trong file
    # => Uoc luong chat luong nen bang cach so sanh he so DCT luong tu hoa
    # giua vung goc trai tren (double-compressed) va phan con lai
    img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
    H, W = img.shape

    # Tinh he so DCT luong tu hoa cho tat ca 8x8 block
    all_blocks_q = []
    tl_nonzero_ratios = []
    rest_nonzero_ratios = []

    for bi in range(H//8):
        for bj in range(W//8):
            block = img[bi*8:bi*8+8, bj*8:bj*8+8]
            F = dct2d(block - 128.0)
            q = np.rint(F / Q50_ref).astype(int)  # he so sau luong tu hoa Q50
            ac_vals = q.flatten()[1:]              # bo DC (vi tri 0,0)
            nonzero_ratio = float(np.count_nonzero(ac_vals)) / 63.0
            energy_ac = float(np.sum(ac_vals**2))
            is_tl = (bi < H//16 and bj < W//16)
            entry = {
                'block': [bi, bj],
                'dc_coeff': int(q[0,0]),
                'ac_nonzero_ratio': round(nonzero_ratio, 4),
                'ac_energy': round(energy_ac, 2),
                'region': 'top_left' if is_tl else 'rest'
            }
            all_blocks_q.append(entry)
            if is_tl:
                tl_nonzero_ratios.append(nonzero_ratio)
            else:
                rest_nonzero_ratios.append(nonzero_ratio)

    tl_mean  = float(np.mean(tl_nonzero_ratios))  if tl_nonzero_ratios  else 0.0
    rest_mean = float(np.mean(rest_nonzero_ratios)) if rest_nonzero_ratios else 0.0
    region_diff = abs(tl_mean - rest_mean)

    # Uoc luong chat luong nhu the nao: block vung double-compress co it AC nonzero hon
    # (Q75 agresive hon Q50 -> nhieu he so bi round ve 0 hon)
    tl_quality_note  = 'cao hon (it zero AC hon)' if tl_mean > rest_mean else 'thap hon (nhieu zero AC hon — double compress)'
    anomaly = region_diff > 0.05  # khac biet > 5% la dang ke

    tables.append({
        'note': 'PNG khong luu bang luong hoa — phan tich he so DCT lượng tu hoa (Q50) de uoc luong',
        'analysis_method': 'DCT quantized coefficient distribution per 8x8 block',
        'quantization_matrix_used': 'Q50_standard',
        'top_left_ac_nonzero_mean': round(tl_mean, 4),
        'rest_ac_nonzero_mean': round(rest_mean, 4),
        'region_difference': round(region_diff, 4),
        'top_left_quality_note': tl_quality_note,
        'anomaly_detected': anomaly,
        'blocks_analyzed': len(all_blocks_q)
    })

result = {
    'file': img_path,
    'format': 'PNG' if is_png else 'JPEG',
    'quantization_tables': len(tables),
    'tables': tables,
    'anomaly_detected': anomaly
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

if is_png:
    t = tables[0]
    print("quantization tables: N/A (PNG) | DCT coefficient analysis via Q50 | anomaly={}".format(anomaly))
    print("  tl_ac_nonzero={:.4f} | rest_ac_nonzero={:.4f} | diff={:.4f}".format(
        t['top_left_ac_nonzero_mean'], t['rest_ac_nonzero_mean'], t['region_difference']))
    print("  Top-left quality: {}".format(t['top_left_quality_note']))
else:
    print("quantization tables: {} | anomaly={}".format(len(tables), anomaly))
    for t in tables:
        print("  Table {}: est_quality=Q{} | diff_from_Q50={}".format(
            t['table_id'], t['estimated_quality'], t['diff_from_Q50']))
print("Saved -> {}".format(out_path))
