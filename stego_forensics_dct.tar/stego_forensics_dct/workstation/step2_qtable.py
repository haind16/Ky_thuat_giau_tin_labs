#!/usr/bin/env python3
import sys, json, struct
import numpy as np
import jpegio as jio

img_path=sys.argv[1] if len(sys.argv)>1 else 'press_release.jpg'
out_path=sys.argv[2] if len(sys.argv)>2 else 'qtable_dump.txt'

# Doc bang luong hoa thuc su tu cau truc JPEG
with open(img_path,'rb') as f: data=f.read()

Q50_ref=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,
         14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,
         18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,
         49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99]

tables=[]; i=0
while i<len(data)-1:
    if data[i]==0xFF and data[i+1]==0xDB:
        length=struct.unpack('>H',data[i+2:i+4])[0]
        seg=data[i+4:i+2+length]; j=0
        while j<len(seg):
            prec=seg[j]>>4; tid=seg[j]&0x0F; j+=1
            if prec==0 and j+64<=len(seg):
                vals=list(seg[j:j+64]); j+=64
                diff=sum(abs(vals[k]-Q50_ref[k]) for k in range(64))
                quality=max(1,min(100,round(100-diff/30)))
                tables.append({'table_id':tid,'values':vals,
                               'diff_from_Q50':diff,'estimated_quality':quality})
            elif prec==1 and j+128<=len(seg):
                vals=[struct.unpack('>H',seg[j+k*2:j+k*2+2])[0] for k in range(64)]; j+=128
                diff=sum(abs(vals[k]-Q50_ref[k]) for k in range(64))
                quality=max(1,min(100,round(100-diff/30)))
                tables.append({'table_id':tid,'values':vals,
                               'diff_from_Q50':diff,'estimated_quality':quality})
            else: break
        i+=2+length
    else:
        i+=1

# Phan tich phan bo he so DCT theo vung (double compression fingerprint)
jpg=jio.read(img_path)
coeffs=jpg.coef_arrays[0]
CH,CW=coeffs.shape

tl_nz=[]; rest_nz=[]
for bi in range(CH//8):
    for bj in range(CW//8):
        block=coeffs[bi*8:bi*8+8,bj*8:bj*8+8].flatten()[1:]
        ratio=float(np.count_nonzero(block))/63.0
        if bi<CH//16 and bj<CW//16: tl_nz.append(ratio)
        else: rest_nz.append(ratio)

tl_mean=float(np.mean(tl_nz)) if tl_nz else 0.0
rest_mean=float(np.mean(rest_nz)) if rest_nz else 0.0
region_diff=abs(tl_mean-rest_mean)
anomaly=(len(tables)>1 and
         abs(tables[0]['estimated_quality']-tables[-1]['estimated_quality'])>5) or region_diff>0.05

result={'file':img_path,'format':'JPEG',
        'quantization_tables':len(tables),'tables':tables,
        'dct_region_analysis':{
            'top_left_ac_nonzero_mean':round(tl_mean,4),
            'rest_ac_nonzero_mean':round(rest_mean,4),
            'region_difference':round(region_diff,4)},
        'anomaly_detected':anomaly}
with open(out_path,'w') as f: json.dump(result,f,indent=2)

print("quantization tables: {} | anomaly={}".format(len(tables),anomaly))
for t in tables:
    print("  Table {}: est_quality=Q{} | diff_from_Q50={}".format(
        t['table_id'],t['estimated_quality'],t['diff_from_Q50']))
print("DCT region: tl_ac_nonzero={:.4f} | rest={:.4f} | diff={:.4f}".format(
    tl_mean,rest_mean,region_diff))
print("Saved -> {}".format(out_path))
