#!/usr/bin/env python3
import sys, json, struct

img_path=sys.argv[1] if len(sys.argv)>1 else 'press_release.jpg'
out_path=sys.argv[2] if len(sys.argv)>2 else 'jpeg_struct.txt'

with open(img_path,'rb') as f: data=f.read()

MARKER_NAMES={0xD8:'SOI',0xE0:'APP0',0xE1:'APP1',0xDB:'DQT',
              0xC0:'SOF0',0xC4:'DHT',0xDA:'SOS',0xD9:'EOI',0xFE:'COM'}
markers=[]; i=0
while i<len(data)-1:
    if data[i]==0xFF and data[i+1] not in (0x00,0xFF):
        m=data[i+1]
        name=MARKER_NAMES.get(m,'APP{}'.format(m-0xE0) if 0xE0<=m<=0xEF else 'UNK_{:02X}'.format(m))
        length=struct.unpack('>H',data[i+2:i+4])[0] if m not in (0xD8,0xD9) else 0
        entry={'offset':i,'marker':'0xFF{:02X}'.format(m),'name':name,'length':length}
        if m==0xDB and length>0:
            # Trich xuat bang luong hoa
            seg=data[i+4:i+2+length]; j=0; qtables=[]
            while j<len(seg):
                if j>=len(seg): break
                tid=seg[j]&0x0F; prec=seg[j]>>4; j+=1
                if prec==0 and j+64<=len(seg):
                    qtables.append({'table_id':tid,'values':list(seg[j:j+64])}); j+=64
            entry['quantization_tables']=qtables
        markers.append(entry)
        i+=2+(length if length else 0)
    else:
        i+=1

result={'file':img_path,'format':'JPEG','size_bytes':len(data),
        'markers':markers,'marker_count':len(markers)}
with open(out_path,'w') as f: json.dump(result,f,indent=2)

print("markers found: {} | format=JPEG | size={} bytes | saved -> {}".format(
    len(markers),len(data),out_path))
for m in markers:
    extra=''
    if 'quantization_tables' in m:
        extra=' [DQT: {} table(s)]'.format(len(m['quantization_tables']))
    print("  {:6d}  {}  {:6s}  (len={}){}".format(
        m['offset'],m['marker'],m['name'],m['length'],extra))
