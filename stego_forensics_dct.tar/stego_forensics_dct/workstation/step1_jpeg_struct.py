#!/usr/bin/env python3
import sys, json, struct

img_path = sys.argv[1] if len(sys.argv) > 1 else 'press_release.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'jpeg_struct.txt'

with open(img_path, 'rb') as f:
    data = f.read()

PNG_SIG = b'\x89PNG\r\n\x1a\n'
is_png = data[:8] == PNG_SIG
markers = []

if is_png:
    i = 8
    while i < len(data) - 8:
        if i + 8 > len(data): break
        length = struct.unpack('>I', data[i:i+4])[0]
        chunk_type = data[i+4:i+8].decode('ascii', errors='replace')
        markers.append({'offset': i, 'marker': chunk_type, 'name': chunk_type, 'length': length})
        if chunk_type == 'IHDR' and length >= 13:
            w, h = struct.unpack('>II', data[i+8:i+16])
            bd = data[i+16]
            ct = {0:'Grayscale',2:'RGB',3:'Indexed',4:'GrayscaleAlpha',6:'RGBA'}.get(data[i+17],'Unknown')
            markers[-1]['detail'] = '{}x{} bit_depth={} color={}'.format(w, h, bd, ct)
        i += 12 + length
else:
    i = 0
    while i < len(data)-1:
        if data[i] == 0xFF and data[i+1] not in (0x00, 0xFF):
            marker = data[i+1]
            name = {0xD8:'SOI',0xE0:'APP0',0xE1:'APP1',0xDB:'DQT',
                    0xC0:'SOF0',0xC4:'DHT',0xDA:'SOS',0xD9:'EOI',0xFE:'COM'}.get(marker,'UNK_{:02X}'.format(marker))
            length = struct.unpack('>H', data[i+2:i+4])[0] if marker not in (0xD8,0xD9) else 0
            markers.append({'offset':i,'marker':'0xFF{:02X}'.format(marker),'name':name,'length':length})
            i += 2 + (length if length else 0)
        else:
            i += 1

result = {
    'file': img_path,
    'format': 'PNG' if is_png else 'JPEG',
    'size_bytes': len(data),
    'markers': markers,
    'marker_count': len(markers)
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("markers found: {} | format={} | file size: {} bytes | saved -> {}".format(
    len(markers), 'PNG' if is_png else 'JPEG', len(data), out_path))
for m in markers:
    detail = m.get('detail', '')
    print("  {:6d}  {:8s}  {:8s}  (len={}) {}".format(
        m['offset'], m['marker'], m['name'], m['length'], detail))
