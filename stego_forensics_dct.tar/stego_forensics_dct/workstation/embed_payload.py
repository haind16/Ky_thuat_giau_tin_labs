#!/usr/bin/env python3
import jpegio as jio
import numpy as np
import hashlib, os, sys

def lcg(s): return (1664525*s+1013904223)%(2**32)

ZIGZAG_AC=[(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
           (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
           (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
           (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)]
REP=3

src='press_release.jpg'
if not os.path.exists(src):
    sys.exit(1)

jpg=jio.read(src)
coeffs=jpg.coef_arrays[0]
CH,CW=coeffs.shape

positions=[]
for bi in range(CH//8):
    for bj in range(CW//8):
        for (r,c) in ZIGZAG_AC:
            pi,pj=bi*8+r, bj*8+c
            if abs(int(coeffs[pi,pj]))>=2:
                positions.append((pi,pj))

secret="FORENSICS_CHALLENGE_2026"
bits=[]
for ch in secret:
    v=ord(ch)
    for i in range(7,-1,-1): bits.append((v>>i)&1)
n=len(bits)
header=[(n>>(31-i))&1 for i in range(32)]
payload=header+bits
payload_rep=[]
for b in payload: payload_rep.extend([b]*REP)

seed_int=int(hashlib.sha256(b"ForensicKey2026").hexdigest(),16)%(2**31)
state=seed_int; order=list(range(len(positions)))
for i in range(len(order)-1,0,-1):
    state=lcg(state); j=state%(i+1); order[i],order[j]=order[j],order[i]

bit_idx=0
for pos_idx in order:
    if bit_idx>=len(payload_rep): break
    pi,pj=positions[pos_idx]
    val=int(coeffs[pi,pj])
    bit=payload_rep[bit_idx]
    if val>0:
        new_val=(val&~1)|bit
        if new_val==0: new_val=2
        coeffs[pi,pj]=new_val
    else:
        abs_val=-val
        new_abs=(abs_val&~1)|bit
        if new_abs==0: new_abs=2
        coeffs[pi,pj]=-new_abs
    bit_idx+=1

jpg.coef_arrays[0]=coeffs
jio.write(jpg,src)
