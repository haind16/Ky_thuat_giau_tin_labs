#!/usr/bin/env python3
"""Usage: python3 step1_scan.py cover.png > blocks.txt"""
import numpy as np
from PIL import Image
import math, sys, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            out[u,v] = 0.25*cu*cv*sum(
                block[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                for j in range(N) for k in range(N))
    return out

img_path = sys.argv[1] if len(sys.argv) > 1 else 'cover.png'
img = Image.open(img_path).convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

total_ac = nonzero = risk1 = shrink_risk = 0
for bi in range(H//8):
    for bj in range(W//8):
        b = arr[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        q = np.round(dct2d(b)/Q50).astype(np.int32)
        for (r,c) in ZIGZAG[1:]:
            total_ac += 1
            v = int(q[r,c])
            if v != 0: nonzero += 1
            if abs(v) == 1: risk1 += 1
            if v == 1: shrink_risk += 1  # F3: 1->0 shrinkage

result = {
    "image": img_path, "size": "{}x{}".format(W, H),
    "blocks": (H//8)*(W//8), "total_ac": total_ac,
    "nonzero_ac": nonzero, "capacity_bits": nonzero,
    "capacity_bytes": nonzero // 8,
    "f3_shrink_risk": shrink_risk,
    "f4_shrink_risk": 0,
    "nonzero_pct": round(nonzero/total_ac*100, 2)
}

print(json.dumps(result, indent=2))
import sys
sys.stderr.write("[OK] {}x{} | {}/{} AC nonzero ({:.1f}%) | capacity ~{} bytes\n".format(
    W, H, nonzero, total_ac, nonzero/total_ac*100, nonzero//8))
sys.stderr.write("[F3 shrink risk: {} | F4 shrink risk: 0 (no positive +1 issue)]\n".format(shrink_risk))
sys.stderr.write("[NEXT] python3 step2_embed.py {} \"YOUR_MESSAGE\" stego_f4.png\n".format(img_path))
