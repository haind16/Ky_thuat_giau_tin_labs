#!/usr/bin/env python3
"""Usage: python3 step3_diff.py cover.png stego_f4.png"""
import numpy as np
from PIL import Image
import math, sys

if len(sys.argv) < 3:
    sys.stderr.write("Usage: python3 step3_diff.py cover.png stego.png\n"); sys.exit(1)

cover = np.array(Image.open(sys.argv[1]).convert('L'), dtype=np.float64)
stego = np.array(Image.open(sys.argv[2]).convert('L'), dtype=np.float64)
diff  = np.abs(cover - stego)
mse   = np.mean(diff**2)
psnr  = 10*math.log10(255**2/mse) if mse > 0 else 999.0

print("=== DIFF REPORT: {} vs {} ===".format(sys.argv[1], sys.argv[2]))
print("PSNR     : {:.4f} dB".format(psnr))
print("MSE      : {:.6f}".format(mse))
print("Changed  : {}/{} pixels ({:.2f}%)".format(
    int((diff>0).sum()), int(cover.size),
    float((diff>0).sum())/float(cover.size)*100))
print("Max diff : {} | Mean diff: {:.4f}".format(int(diff.max()), diff.mean()))

# Tao diff image x10 de xem bang fim
diff_vis = np.clip(diff * 10, 0, 255).astype(np.uint8)
Image.fromarray(diff_vis, 'L').save('diff_x10.png')
print("\nASCII heatmap (64x32, moi o = 4x8 pixels):")
print("  [.]=khong doi  [+]=thay doi nhe  [X]=thay doi nhieu")
for r in range(0, min(32, cover.shape[0]), 1):
    row = ""
    for c in range(0, cover.shape[1], 2):
        v = float(np.sum(diff[r*4:(r+1)*4, c*2:(c+1)*2]))
        row += "." if v==0 else ("+" if v<5 else "X")
    print("  " + row)

print("\n[OK] diff_x10.png -- xem bang: fim diff_x10.png")
print("[NEXT] scp stego_f4.png key.txt bob@172.25.0.22:~/")
