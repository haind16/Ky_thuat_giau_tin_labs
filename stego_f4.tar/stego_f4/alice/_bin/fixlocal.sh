#!/bin/bash
# Hệ thống systemd tự động kích hoạt SSH khi khởi chạy. 
# File này được để trống để không gây xung đột tiến trình.
exit 0
