#!/bin/bash
# Tao thu muc /run/sshd va cap quyen
mkdir -p /run/sshd
chmod 755 /run/sshd
# Sinh host keys de khong bi loi tu choi ket noi
ssh-keygen -A 2>/dev/null
# Chay tien trinh SSH ngam
/usr/sbin/sshd
