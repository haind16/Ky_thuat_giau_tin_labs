=== ALICE: GIAU TIN BANG F4 ===

B0: Kiem tra anh goc bang cong cu Linux
  file cover.png
  exiftool cover.png
  xxd cover.png | head -4

B1: Quet thong tin anh va uoc tinh dung luong
  python3 step1_scan.py cover.png

B2: Thuc hien giau thong diep vao anh stego
  python3 step2_embed.py cover.png "[NHAP_THONG_DIEP_TAI_DAY]" stego_f4.png
  (Vi du: python3 step2_embed.py cover.png "SecretMessage123" stego_f4.png)
  (Luu y: Chay lenh nay se tu dong tao them file anh xam goc 'cover_gray.png')

B3: Xem bao cao chenh lech chat luong anh (PSNR/MSE)
  python3 step3_diff.py cover.png stego_f4.png

B4: Mo xem truc quan anh chenh lech va anh stego bang lenh fim (khong bi treo terminal)
  fim diff_x10.png
  fim stego_f4.png

B5: Gui file anh stego, file anh xam goc va key sang cho Bob qua SCP
  scp stego_f4.png cover_gray.png key.txt ubuntu@172.25.0.22:~/
  (Password mac dinh la: ubuntu)

XONG: Chuyen sang cua so Bob de tien hanh tach tin!
