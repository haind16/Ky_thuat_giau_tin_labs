#!/usr/bin/env python3
import sys, json, os

try:
    with open('key.txt') as f: 
        key = json.load(f)
    
    # Hỗ trợ cả hai định dạng key cũ (msg_bits) và mới (nbits) để không bị lỗi cấu trúc
    msg_bits = key.get('nbits') if key.get('nbits') is not None else key.get('msg_bits', 0)
    
    print("=== HEADER INFO ===")
    print("Payload length from key: {} bits = {} bytes".format(msg_bits, msg_bits//8))
    print("\nF4 parity rules:")
    print("  q > 0: parity = q % 2")
    print("  q < 0: parity = (q + 1) % 2")
    print("  abs(q) <= 1: skip (prevent bit-shifting)")
    
    # Ghi lại file cấu hình đệm header.txt để phục vụ các bước sau nếu cần
    with open('header.txt','w') as f: 
        f.write(json.dumps({"msg_bits": msg_bits}))
except Exception as e:
    print("[LOI] Khong doc duoc key.txt. Kiem tra lai da SCP chua!")
