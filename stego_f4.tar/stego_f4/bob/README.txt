=== BOB: TACH TIN F4 ===

B0: Cho Alice SCP xong, kiem tra cac file nhan duoc
  ls -lh stego_f4.png cover_gray.png key.txt
  exiftool stego_f4.png
  xxd stego_f4.png | head -8

B1: Kiem tra do dai chuoi bit can trich xuat tu Key
  python3 step1_header.py stego_f4.png

B2: Thuc hien giai ma va trich xuat tin nhan bi mat
  python3 step2_extract.py stego_f4.png
  cat secret.txt

B3: Chuyen ma tran xac minh ket qua toan ven (So sanh truc tiep voi anh xam cover_gray.png nhan duoc)
  python3 step3_verify.py stego_f4.png secret.txt cover_gray.png

B4: Mo xem anh stego va anh xam goc nhan duoc de so sanh bang mat thuong
  fim stego_f4.png
  fim cover_gray.png

XONG: Quay lai terminal may host go 'stoplab' roi 'checkwork' de cham diem!
