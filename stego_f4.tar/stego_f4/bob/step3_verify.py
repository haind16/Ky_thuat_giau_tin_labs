#!/usr/bin/env python3
"""Usage: python3 step3_verify.py stego_f4.png secret.txt cover.png"""
import numpy as np
from PIL import Image
import math, sys

stego_path = sys.argv[1] if len(sys.argv) > 1 else 'stego_f4.png'
secret_path = sys.argv[2] if len(sys.argv) > 2 else 'secret.txt'
cover_path  = sys.argv[3] if len(sys.argv) > 3 else 'cover.png'

stego = np.array(Image.open(stego_path).convert('L'), dtype=np.float64)

with open(secret_path) as f: msg = f.read().strip()
print("=== VERIFY ===")
print("Secret   : '{}'".format(msg))
print("Length   : {} chars".format(len(msg)))

if cover_path:
    try:
        cover = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
        diff = np.abs(cover - stego)
        mse  = np.mean(diff**2)
        psnr = 10*math.log10(255**2/mse) if mse > 0 else 999.0
        print("PSNR     : {:.4f} dB".format(psnr))
        print("Changed  : {}/{} pixels ({:.2f}%)".format(
            int((diff>0).sum()), int(cover.size),
            float((diff>0).sum())/float(cover.size)*100))
        print("F4 quality: {}".format(
            "EXCELLENT (>=40dB)" if psnr >= 40 else "GOOD (>=35dB)" if psnr >= 35 else "OK"))
    except: pass

print("\nF3 vs F4 (so sanh nhanh):")
print("  {:20} {:>8} {:>8}".format("Tieu chi","F3","F4"))
print("  " + "-"*38)
print("  {:20} {:>8} {:>8}".format("Shrinkage source","q=+/-1","q=+1 only"))
print("  {:20} {:>8} {:>8}".format("Shrinkage rate","cao hon","thap hon"))
print("  {:20} {:>8} {:>8}".format("Parity (q<0)","binh thuong","dao nguoc"))
print("  {:20} {:>8} {:>8}".format("Hist. attack","kho","kho hon"))
sys.stderr.write("[DONE] Xac minh xong!\n")
sys.stderr.write("[EXTRA] fim stego_f4.png  |  exiftool stego_f4.png  |  xxd stego_f4.png | head -8\n")
