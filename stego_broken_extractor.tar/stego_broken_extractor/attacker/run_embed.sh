#!/bin/bash
echo "[2026-05-15 03:12:44] channel.png generated: 256x256 grayscale" > embed_log.txt
echo "[2026-05-15 03:12:45] DCT applied: 8x8 blocks, Q50 quantization matrix" >> embed_log.txt
echo "[2026-05-15 03:12:45] AC carrier positions (|val|>=2) collected: BEFORE embedding" >> embed_log.txt
echo "[2026-05-15 03:12:46] F4-style LSB embed: decrease magnitude, never cross zero" >> embed_log.txt
echo "[2026-05-15 03:12:46] WARNING: F4 shrinkage changes position list after embedding" >> embed_log.txt
echo "[2026-05-15 03:12:46] positions saved separately: channel_positions.npy" >> embed_log.txt
echo "[2026-05-15 03:12:47] key: DCTKey_** [redacted] -- sha256 mod ???" >> embed_log.txt
echo "[2026-05-15 03:12:50] extractor issues detected (see notes.txt)" >> embed_log.txt
echo "[2026-05-15 03:13:01] session closed" >> embed_log.txt

echo "ghi chu cua attacker:" > notes.txt
echo "" >> notes.txt
echo "- nhung trong mien DCT: he so AC khoi 8x8 sau luong tu hoa Q50" >> notes.txt
echo "- F4-style: giam magnitude de set LSB, khong bao gio cho val qua 0" >> notes.txt
echo "- VAN DE: sau khi nhung, mot so he so |val|=2 bi giam xuong |val|=1" >> notes.txt
echo "  => danh sach vi tri THAY DOI sau khi nhung (F4 shrinkage)" >> notes.txt
echo "  => phai dung positions TRUOC KHI NHUNG, da luu vao channel_positions.npy" >> notes.txt
echo "" >> notes.txt
echo "extractor can sua 3 loi:" >> notes.txt
echo "  1. sha256(key) mod (2^31) -- kiem tra dong seed" >> notes.txt
echo "  2. header dai 32 bit -- extractor doc bao nhieu bit?" >> notes.txt
echo "  3. positions: tinh lai tu coeffs da nhung HAY load tu file?" >> notes.txt

echo "[+] embed_log.txt generated"
echo "[+] notes.txt generated"
