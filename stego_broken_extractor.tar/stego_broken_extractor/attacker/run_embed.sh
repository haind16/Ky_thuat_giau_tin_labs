#!/bin/bash
python3 embed.py

echo "[2026-05-15 03:12:44] channel_plain.jpg input: 256x256 grayscale JPEG" > embed_log.txt
echo "[2026-05-15 03:12:45] DCT applied: 8x8 blocks, Q50 quantization" >> embed_log.txt
echo "[2026-05-15 03:12:45] AC carrier: coefficients with |val| >= 2 selected" >> embed_log.txt
echo "[2026-05-15 03:12:46] payload embedded: 208 bits into DCT coefficients" >> embed_log.txt
echo "[2026-05-15 03:12:46] key: DCTKey_** [redacted] -- sha256 mod ???" >> embed_log.txt
echo "[2026-05-15 03:12:50] WARNING: extractor may have issues (see notes.txt)" >> embed_log.txt
echo "[2026-05-15 03:13:01] session closed" >> embed_log.txt

echo "ghi chu cua attacker:" > notes.txt
echo "" >> notes.txt
echo "- nhung vao he so DCT cua anh JPEG that (khong phai pixel)" >> notes.txt
echo "- chi dung he so AC co |val| >= 2 lam carrier" >> notes.txt
echo "- DC coefficient (goc trai tren moi khoi 8x8) khong duoc dung" >> notes.txt
echo "- shuffle: LCG voi seed = sha256(key) mod ??? -- kiem tra modulus" >> notes.txt
echo "- header: ? bit -- extractor dang doc bao nhieu?" >> notes.txt
echo "- nguong AC: |val| >= ? -- co khop voi luc embed khong?" >> notes.txt

echo "[+] channel.jpg generated (payload embedded)"
echo "[+] embed_log.txt generated"
echo "[+] notes.txt generated"
