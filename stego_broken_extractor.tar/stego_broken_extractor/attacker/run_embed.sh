#!/bin/bash
echo "[2026-05-15 03:12:44] channel.png generated: 256x256 grayscale" > embed_log.txt
echo "[2026-05-15 03:12:45] payload embedded: 216 bits (27 bytes + 4 header)" >> embed_log.txt
echo "[2026-05-15 03:12:45] key: ChannelK**_****  [redacted]" >> embed_log.txt
echo "[2026-05-15 03:12:46] extractor uploaded: broken_extract.py v0.3" >> embed_log.txt
echo "[2026-05-15 03:12:47] verification: SKIPPED -- time constraint" >> embed_log.txt
echo "[2026-05-15 03:12:50] WARNING: extractor may have issues (see notes.txt)" >> embed_log.txt
echo "[2026-05-15 03:13:01] session closed" >> embed_log.txt

echo "ghi chu cua attacker:" > notes.txt
echo "" >> notes.txt
echo "- can kiem tra lai extractor, shuffle co ve sai (modulus?)" >> notes.txt
echo "- phan header: co the dang doc thieu bit, dem lai xem" >> notes.txt
echo "- dieu kien loc pixel: val<2 co the qua rong, luc nhung dung chat hon" >> notes.txt
echo "- key: ChannelKey_2026 -- khong chia se truc tiep" >> notes.txt
echo "" >> notes.txt
echo "de lai cho analyst:" >> notes.txt
echo "  - sha256(key) mod (2^31) -- kiem tra dong nay" >> notes.txt
echo "  - header dai 32 bit -- extractor dang doc bao nhieu?" >> notes.txt
echo "  - pixel skip: val<4 or val>251 -- co khop khong?" >> notes.txt

echo "[+] embed_log.txt generated"
echo "[+] notes.txt generated"
