#!/usr/bin/env python3
"""
Chay trong container attacker de nhung payload vao channel_plain.jpg
va tao ra channel.jpg (da co payload trong he so DCT).
"""
import jpegio as jio
import numpy as np
import hashlib, os

def lcg(s): return (1664525*s+1013904223) % (2**32)

jpg = jio.read('channel_plain.jpg')
coeffs = jpg.coef_arrays[0]
CH, CW = coeffs.shape

positions = []
for i in range(CH):
    for j in range(CW):
        if i%8==0 and j%8==0: continue
        if abs(int(coeffs[i,j])) >= 2:
            positions.append((i,j))

print("[1] Positions AC |val|>=2: {}".format(len(positions)))

key = b"DCTKey_2026"
seed = int(hashlib.sha256(key).hexdigest(), 16) % (2**31)
state = seed
order = list(range(len(positions)))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

secret = "PAYLOAD_RECOVERED_2026"
bits = []
for c in secret:
    v = ord(c)
    for i in range(7,-1,-1): bits.append((v>>i)&1)
n = len(bits)
header = [(n>>(31-i))&1 for i in range(32)]
payload = header + bits

print("[2] Payload: '{}' | n_bits={} | total={}".format(secret, n, len(payload)))

bit_idx = 0
for pos_idx in order:
    if bit_idx >= len(payload): break
    pi, pj = positions[pos_idx]
    val = int(coeffs[pi,pj])
    bit = payload[bit_idx]
    if val > 0:
        new_val = (val & ~1) | bit
        if new_val == 0: new_val = 2
        coeffs[pi,pj] = new_val
    else:
        abs_val = -val
        new_abs = (abs_val & ~1) | bit
        if new_abs == 0: new_abs = 2
        coeffs[pi,pj] = -new_abs
    bit_idx += 1

print("[3] Embedded: {}/{} bits".format(bit_idx, len(payload)))

jpg.coef_arrays[0] = coeffs
jio.write(jpg, 'channel.jpg')
print("[4] Saved: channel.jpg (da co payload trong he so DCT)")
