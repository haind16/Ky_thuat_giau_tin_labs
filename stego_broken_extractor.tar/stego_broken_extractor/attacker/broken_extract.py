#!/usr/bin/env python3
import jpegio as jio
import numpy as np
import sys, hashlib

def lcg(s): return (1664525*s+1013904223) % (2**32)

img_path = sys.argv[1] if len(sys.argv) > 1 else 'channel.jpg'
key      = sys.argv[2] if len(sys.argv) > 2 else 'DCTKey_2026'
out_path = sys.argv[3] if len(sys.argv) > 3 else 'output.txt'

jpg    = jio.read(img_path)
coeffs = jpg.coef_arrays[0]
CH, CW = coeffs.shape

# BUG-3: nguong >= 1 thay vi >= 2
positions = []
for i in range(CH):
    for j in range(CW):
        if i%8==0 and j%8==0: continue
        if abs(int(coeffs[i,j])) >= 1:
            positions.append((i,j))

# BUG-1: % (2**32) thay vi % (2**31)
seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**32)
state = seed
order = list(range(len(positions)))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

# BUG-2: doc 31 bit header thay vi 32
header_bits = []
order_idx = 0
while order_idx < len(order) and len(header_bits) < 31:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = positions[pos_idx]
    val = int(coeffs[pi,pj])
    header_bits.append(val & 1 if val > 0 else (-val) & 1)

n_bits = 0
for b in header_bits: n_bits = (n_bits << 1) | b

payload_bits = []
while order_idx < len(order) and len(payload_bits) < min(n_bits, 2000):
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = positions[pos_idx]
    val = int(coeffs[pi,pj])
    payload_bits.append(val & 1 if val > 0 else (-val) & 1)

chars = []
for i in range(0, len(payload_bits)-7, 8):
    byte = 0
    for b in payload_bits[i:i+8]: byte = (byte << 1) | b
    chars.append(chr(byte) if 32 <= byte <= 126 else '?')
message = ''.join(chars)

with open(out_path, 'w') as f:
    f.write("positions_used: {}\n".format(len(positions)))
    f.write("header_n_bits: {}\n".format(n_bits))
    f.write("printable: {:.1f}%\n".format(
        100*sum(1 for c in message if c!='?')/max(len(message),1)))
    f.write("preview: {}\n".format(message[:32]))

print("Done | positions={} | header_n_bits={} | out -> {}".format(
    len(positions), n_bits, out_path))
print("Preview: {}".format(message[:32]))
