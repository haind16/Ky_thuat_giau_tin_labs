#!/usr/bin/env python3
import numpy as np
from PIL import Image
import sys, hashlib

def lcg(s): return (1664525*s+1013904223) % (2**32)

img_path = sys.argv[1] if len(sys.argv) > 1 else 'channel.png'
key      = sys.argv[2] if len(sys.argv) > 2 else 'ChannelKey_2026'
out_path = sys.argv[3] if len(sys.argv) > 3 else 'recovered.txt'

pixels = np.array(Image.open(img_path).convert('L'), dtype=np.uint8)
H, W = pixels.shape
all_px = [(i,j) for i in range(H) for j in range(W)]

seed_int = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
state = seed_int
order = list(range(H*W))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

header_bits = []
order_idx = 0
while order_idx < len(order) and len(header_bits) < 32:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_px[pos_idx]
    val = int(pixels[pi, pj])
    if val < 4 or val > 251: continue
    header_bits.append(val & 1)

n_bits = 0
for b in header_bits: n_bits = (n_bits << 1) | b

if n_bits <= 0 or n_bits > 8000:
    print("Loi: n_bits={} — sai key hoac extractor chua duoc sua".format(n_bits))
    sys.exit(1)

payload_bits = []
while order_idx < len(order) and len(payload_bits) < n_bits:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_px[pos_idx]
    val = int(pixels[pi, pj])
    if val < 4 or val > 251: continue
    payload_bits.append(val & 1)

chars = []
for i in range(0, len(payload_bits)-7, 8):
    byte = 0
    for b in payload_bits[i:i+8]: byte = (byte << 1) | b
    chars.append(chr(byte) if 32 <= byte <= 126 else '?')

message = ''.join(chars)

with open(out_path, 'w') as f:
    f.write(message + '\n')

print("PAYLOAD_RECOVERED_2026" if "PAYLOAD_RECOVERED_2026" in message else "Ket qua: {}".format(message))
