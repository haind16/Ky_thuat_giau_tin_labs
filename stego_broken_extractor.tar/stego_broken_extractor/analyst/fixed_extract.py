#!/usr/bin/env python3
import numpy as np
import sys, hashlib

def lcg(s): return (1664525*s+1013904223) % (2**32)

coeffs_path    = sys.argv[1] if len(sys.argv) > 1 else 'channel_coeffs.npy'
positions_path = sys.argv[2] if len(sys.argv) > 2 else 'channel_positions.npy'
key            = sys.argv[3] if len(sys.argv) > 3 else 'DCTKey_2026'
out_path       = sys.argv[4] if len(sys.argv) > 4 else 'recovered.txt'

coeffs = np.load(coeffs_path)
# Dung: load positions TRUOC KHI NHUNG (tranh F4 shrinkage)
positions = [tuple(p) for p in np.load(positions_path)]

# Dung: % (2**31)
seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
state = seed
order = list(range(len(positions)))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

# Dung: doc du 32 bit
header_bits = []
order_idx = 0
while order_idx < len(order) and len(header_bits) < 32:
    pos_idx = order[order_idx]; order_idx += 1
    bi,bj,u,v = positions[pos_idx]
    val = int(coeffs[bi,bj,u,v])
    header_bits.append(val & 1 if val > 0 else (-val) & 1)

n_bits = 0
for b in header_bits: n_bits = (n_bits << 1) | b

if n_bits <= 0 or n_bits > 8000:
    print("Loi: n_bits={} — sai key hoac chua sua xong".format(n_bits))
    sys.exit(1)

payload_bits = []
while order_idx < len(order) and len(payload_bits) < n_bits:
    pos_idx = order[order_idx]; order_idx += 1
    bi,bj,u,v = positions[pos_idx]
    val = int(coeffs[bi,bj,u,v])
    payload_bits.append(val & 1 if val > 0 else (-val) & 1)

chars = []
for i in range(0, len(payload_bits)-7, 8):
    byte = 0
    for b in payload_bits[i:i+8]: byte = (byte << 1) | b
    chars.append(chr(byte) if 32 <= byte <= 126 else '?')

message = ''.join(chars)

with open(out_path, 'w') as f:
    f.write(message + '\n')

print("PAYLOAD_RECOVERED_2026" if "PAYLOAD_RECOVERED_2026" in message
      else "Ket qua: {}".format(message))
