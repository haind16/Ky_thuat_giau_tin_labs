=== LAB: BROKEN EXTRACTOR — FORENSIC PAYLOAD RECOVERY ===

NOTE: Tren container attacker chay truoc:
  sudo systemctl status ssh
  ./run_embed.sh
  ls

B0: Tren analyst -- lay evidence tu attacker
  sudo systemctl status ssh
  scp ubuntu@174.20.0.10:embed_log.txt .
  scp ubuntu@174.20.0.10:notes.txt .
  cat embed_log.txt
  cat notes.txt

B1: Kiem tra anh va chay extractor loi
  file channel.png
  xxd channel.png | head -8
  strings channel.png | head -20
  python3 broken_extract.py channel.png ChannelKey_2026 output.txt
  cat output.txt

B2: Tim va sua 3 loi trong broken_extract.py
  nano broken_extract.py

  Sua dong 1:
    % (2**32)  ->  % (2**31)

  Sua dong 2:
    len(header_bits) < 31  ->  len(header_bits) < 32

  Sua dong 3 (2 cho):
    if val < 2 or val > 253  ->  if val < 4 or val > 251

B3: Chay lai sau khi da sua -- kiem tra ket qua
  python3 broken_extract.py channel.png ChannelKey_2026 output2.txt
  cat output2.txt

B4: Xac nhan payload bang fixed extractor
  python3 fixed_extract.py channel.png ChannelKey_2026 recovered.txt
  cat recovered.txt

  checkwork
  stoplab
