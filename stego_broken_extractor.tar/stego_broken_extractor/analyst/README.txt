=== LAB: BROKEN EXTRACTOR -- DCT DOMAIN FORENSIC PAYLOAD RECOVERY ===

NOTE: Tren container attacker chay truoc:
  sudo systemctl status ssh
  ./run_embed.sh
  ls

B0: Lay evidence tu attacker
  sudo systemctl status ssh
  scp ubuntu@174.20.0.10:channel.jpg .
  scp ubuntu@174.20.0.10:broken_extract.py .
  scp ubuntu@174.20.0.10:embed_log.txt .
  scp ubuntu@174.20.0.10:notes.txt .
  cat embed_log.txt
  cat notes.txt

B1: Kiem tra anh JPEG va he so DCT
  file channel.jpg
  xxd channel.jpg | head -8
  strings channel.jpg | head -20
  cat > analyze_dct.py << 'PYEOF'
import jpegio as jio
jpg = jio.read('channel.jpg')
c = jpg.coef_arrays[0]
ac1 = sum(1 for i in range(256) for j in range(256)
          if not(i%8==0 and j%8==0) and abs(int(c[i,j]))>=1)
ac2 = sum(1 for i in range(256) for j in range(256)
          if not(i%8==0 and j%8==0) and abs(int(c[i,j]))>=2)
print('AC |val|>=1:', ac1)
print('AC |val|>=2:', ac2)
print('Block[0,0] DC:', int(c[0,0]))
PYEOF
  python3 analyze_dct.py

B2: Chay extractor loi -- quan sat output sai
  python3 broken_extract.py channel.jpg DCTKey_2026 output.txt
  cat output.txt

B3: Tim va sua 3 loi trong broken_extract.py
  # Doc notes.txt de tim goi y
  nano broken_extract.py

  Sua loi 1 -- PRNG modulus (1 cho):
    % (2**32)  ->  % (2**31)

  Sua loi 2 -- So bit header (1 cho):
    len(header_bits) < 31  ->  len(header_bits) < 32

  Sua loi 3 -- Nguong he so AC (1 cho):
    abs(int(coeffs[i,j])) >= 1  ->  abs(int(coeffs[i,j])) >= 2

B4: Chay lai sau khi da sua
  python3 broken_extract.py channel.jpg DCTKey_2026 output2.txt
  cat output2.txt

B5: Xac nhan bang fixed extractor
  python3 fixed_extract.py channel.jpg DCTKey_2026 recovered.txt
  cat recovered.txt

  checkwork
  stoplab
