=== LAB: BROKEN EXTRACTOR — DCT DOMAIN FORENSIC PAYLOAD RECOVERY ===

NOTE: Tren container attacker chay truoc:
  sudo systemctl status ssh
  ./run_embed.sh
  ls

B0: Kiem tra SSH va lay evidence tu attacker
  sudo systemctl status ssh
  scp ubuntu@174.20.0.10:channel.png .
  scp ubuntu@174.20.0.10:channel_coeffs.npy .
  scp ubuntu@174.20.0.10:channel_positions.npy .
  scp ubuntu@174.20.0.10:broken_extract.py .
  scp ubuntu@174.20.0.10:embed_log.txt .
  scp ubuntu@174.20.0.10:notes.txt .
  cat embed_log.txt
  cat notes.txt

B1: Kiem tra anh va he so DCT
  file channel.png
  xxd channel.png | head -8
  cat > dct_inspect.py << 'PYEOF'
import numpy as np
c = np.load('channel_coeffs.npy')
p = np.load('channel_positions.npy')
after = sum(1 for bi,bj,u,v in p if abs(int(c[bi,bj,u,v])) >= 2)
print('positions truoc khi nhung:', len(p))
print('positions con lai sau nhung:', after)
print('F4 shrinkage:', len(p)-after, 'vi tri bi mat')
PYEOF
  python3 dct_inspect.py

B2: Chay extractor loi — quan sat output sai
  python3 broken_extract.py channel_coeffs.npy DCTKey_2026 output.txt
  cat output.txt

B3: Tim va sua 3 loi trong broken_extract.py
  # Doc notes.txt de tim goi y
  nano broken_extract.py

  Sua loi 1 — PRNG modulus (1 cho):
    % (2**32)  ->  % (2**31)

  Sua loi 2 — So bit header (1 cho):
    len(header_bits) < 31  ->  len(header_bits) < 32

  Sua loi 3 — Cach lay positions (F4 shrinkage):
    # Comment dong tinh lai positions:
    #positions = []
    #for bi in range(BH):
    #    for bj in range(BW):
    #        for u in range(8):
    #            for v in range(8):
    #                if u==0 and v==0: continue
    #                if abs(int(coeffs[bi,bj,u,v])) >= 2:
    #                    positions.append((bi,bj,u,v))
    # Them dong load tu file:
    positions = [tuple(p) for p in np.load('channel_positions.npy')]

B4: Chay lai sau khi da sua
  python3 broken_extract.py channel_coeffs.npy DCTKey_2026 output2.txt
  cat output2.txt

B5: Xac nhan bang fixed extractor
  python3 fixed_extract.py channel_coeffs.npy channel_positions.npy DCTKey_2026 recovered.txt
  cat recovered.txt

  checkwork
  stoplab
