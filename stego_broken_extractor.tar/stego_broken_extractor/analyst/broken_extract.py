#!/usr/bin/env python3
import numpy as np
from PIL import Image
import sys, hashlib

def lcg(s): return (1664525*s+1013904223) % (2**32)

img_path = sys.argv[1] if len(sys.argv) > 1 else 'channel.png'
key      = sys.argv[2] if len(sys.argv) > 2 else 'ChannelKey_2026'
out_path = sys.argv[3] if len(sys.argv) > 3 else 'output.txt'

pixels = np.array(Image.open(img_path).convert('L'), dtype=np.uint8)
H, W = pixels.shape
all_px = [(i,j) for i in range(H) for j in range(W)]

seed_int = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**32)
state = seed_int
order = list(range(H*W))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

header_bits = []
order_idx = 0
while order_idx < len(order) and len(header_bits) < 31:
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_px[pos_idx]
    val = int(pixels[pi, pj])
    if val < 2 or val > 253: continue
    header_bits.append(val & 1)

n_bits = 0
for b in header_bits: n_bits = (n_bits << 1) | b

payload_bits = []
while order_idx < len(order) and len(payload_bits) < min(n_bits, 2000):
    pos_idx = order[order_idx]; order_idx += 1
    pi, pj = all_px[pos_idx]
    val = int(pixels[pi, pj])
    if val < 2 or val > 253: continue
    payload_bits.append(val & 1)

chars = []
for i in range(0, len(payload_bits)-7, 8):
    byte = 0
    for b in payload_bits[i:i+8]: byte = (byte << 1) | b
    chars.append(chr(byte) if 32 <= byte <= 126 else '?')

message = ''.join(chars)
n_header = int.from_bytes(bytes([(n_bits>>(24-i*8))&0xFF for i in range(4)]), 'big')

with open(out_path, 'w') as f:
    f.write("header_n_bits: {}\n".format(n_bits))
    f.write("printable: {:.1f}%\n".format(100*sum(1 for c in message if c!='?')/max(len(message),1)))
    f.write("preview: {}\n".format(message[:32]))

print("Done | header_n_bits={} | out -> {}".format(n_bits, out_path))
print("Preview: {}".format(message[:32]))
