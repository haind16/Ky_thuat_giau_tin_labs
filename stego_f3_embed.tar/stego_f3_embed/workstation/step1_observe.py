#!/usr/bin/env python3
import numpy as np
from PIL import Image

print("=" * 55)
print("  BUOC 1: QUAN SAT ANH GOC")
print("=" * 55)

img = Image.open('cover.png').convert('L')
arr = np.array(img)
H, W = arr.shape

print("Kich thuoc : {}x{} | Grayscale 8-bit".format(W, H))
print("Pixel range: {}-{} | Mean: {:.1f} | Std: {:.1f}".format(
    int(arr.min()), int(arr.max()), arr.mean(), arr.std()))
print("So block 8x8: {}".format((H//8)*(W//8)))

v = np.array([
    arr[bi*8:(bi+1)*8, bj*8:(bj+1)*8].astype(float).var()
    for bi in range(H//8) for bj in range(W//8)
])
flat = int((v < 50).sum())
rich = int((v >= 500).sum())
mid  = len(v) - flat - rich
print("\nTexture ({} block total):".format(len(v)))
print("  Phang  : {:3d} ({:.0f}%)  Trung binh: {:3d} ({:.0f}%)  Phong phu: {:3d} ({:.0f}%)".format(
    flat, flat/len(v)*100, mid, mid/len(v)*100, rich, rich/len(v)*100))

print("\nBlock (0,0) pixel values:")
for row in arr[0:8, 0:8]:
    print("  " + " ".join("{:3d}".format(int(x)) for x in row))

print("\n[DONE] BUOC 1 HOAN THANH")
