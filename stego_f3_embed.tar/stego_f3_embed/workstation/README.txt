=== LAB: GIAU TIN JPEG BANG THUAT TOAN F3 ===

BUOC 0: Kiem tra anh goc bang cong cu Linux
  file cover.png
  exiftool cover.png
  xxd cover.png | head -4

BUOC 1: Quan sat anh
  python3 step1_observe.py

BUOC 2: Bien doi DCT
  python3 step2_dct.py

BUOC 3: Zigzag scan
  python3 step3_zigzag.py

BUOC 4: F3 Embedding
  python3 step4_f3.py

BUOC 5: Phan tich bang Python va ImageMagick
  python3 step5_analyze.py
  md5sum cover.png output/stego_f3.png
  
  # Tao anh highlight diem khac biet bang ImageMagick:
  compare cover.png output/stego_f3.png -highlight-color Red output/diff_compare.png

  # Xem truc tiep anh chenh lech tren Terminal bang ASCII art:
  # (Tham so -W 100 giup hinh anh hien thi rong hon tren man hinh)
  img2txt -W 100 output/diff_compare.png

KHI XONG: stoplab
