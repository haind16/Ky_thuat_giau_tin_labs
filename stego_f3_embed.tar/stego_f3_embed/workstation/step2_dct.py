#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math

print("=" * 55)
print("  BUOC 2: BIEN DOI DCT")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
block = arr[0:8, 0:8] - 128.0

print("Block (0,0) pixel - 128:")
for row in block.astype(int):
    print("  " + " ".join("{:5d}".format(v) for v in row))

print("\nDang tinh DCT...")
dct_b = dct2d(block)
q = np.round(dct_b / Q50).astype(np.int32)

print("\nHe so DCT sau luong tu hoa Q50:")
for row in q:
    print("  " + " ".join("{:4d}".format(v) for v in row))

H, W = arr.shape
total_ac, nonzero_ac, risk1 = 0, 0, 0
print("\nDang quet toan bo {} block...".format((H//8)*(W//8)))
for bi in range(H//8):
    for bj in range(W//8):
        b = arr[bi*8:(bi+1)*8, bj*8:(bj+1)*8] - 128.0
        qq = np.round(dct2d(b) / Q50).astype(np.int32)
        for u in range(8):
            for v in range(8):
                if u==0 and v==0: continue
                total_ac += 1
                if qq[u,v] != 0: nonzero_ac += 1
                if abs(qq[u,v]) == 1: risk1 += 1

print("AC tong: {} | Nonzero: {} ({:.1f}%) | Shrinkage risk(|q|=1): {}".format(
    total_ac, nonzero_ac, nonzero_ac/total_ac*100, risk1))
print("Dung luong toi da: ~{} bit = ~{} byte".format(nonzero_ac, nonzero_ac//8))

print("\n[OK] Xem header hex cua anh:")
print("\n[GOI Y] Chay them: xxd cover.png | head -4")
print("[OK] BUOC 2 HOAN THANH -- chay: python3 step3_zigzag.py")
