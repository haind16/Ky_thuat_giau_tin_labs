#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, json

print("=" * 55)
print("  BUOC 5: PHAN TICH")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

def get_ac(arr):
    H, W = arr.shape
    ac = []
    for bi in range(H//8):
        for bj in range(W//8):
            b = arr[bi*8:(bi+1)*8,bj*8:(bj+1)*8] - 128.0
            q = np.round(dct2d(b)/Q50).astype(np.int32)
            for (r,c) in ZIGZAG[1:]:
                ac.append(int(q[r,c]))
    return np.array(ac)

cover = np.array(Image.open('cover.png').convert('L'), dtype=np.float64)
stego = np.array(Image.open('output/stego_f3.png').convert('L'), dtype=np.float64)

diff = np.abs(cover - stego)
mse  = np.mean(diff**2)
psnr = 10*math.log10(255**2/mse) if mse > 0 else 999.0

print("PSNR: {:.2f} dB | Pixel thay doi: {}/{} ({:.2f}%)".format(
    psnr, int((diff>0).sum()), int(cover.size),
    float((diff>0).sum())/float(cover.size)*100))

# Tao anh diff x10 de luu lai (khong bat sinh vien xem tren terminal nua)
diff_vis = np.clip(diff * 10, 0, 255).astype(np.uint8)
Image.fromarray(diff_vis, 'L').save('output/diff_x10.png')

print("\n--- BAN DO CHENH LECH PIXEL (ASCII) ---")
print("Goc trai tren cung cua anh (Kich thuoc 64x64 pixel):")
grid_diff = diff[:64, :64]
for r in range(0, 64, 2):
    row_str = ""
    for c in range(0, 64, 2):
        val = np.sum(grid_diff[r:r+2, c:c+2])
        if val == 0: row_str += "."    # Khong thay doi
        elif val < 3: row_str += "*"   # Thay doi nhe
        else: row_str += "X"           # Thay doi nhieu
    print("  " + row_str)
print("(. = Giong nhau | * = Thay doi nhe | X = Thay doi nhieu)")
print("=> Ban co nhan thay su thay doi dien ra theo tung khoi 8x8 khong?")

print("\nDang tinh AC coefficients (vui long doi vai giay)...")
c_ac = get_ac(cover)
s_ac = get_ac(stego)

print("\nHistogram AC (-5 den +5):")
print("  {:>4} {:>8} {:>8} {:>6}".format("val","Cover","Stego","Diff"))
print("  " + "-"*28)
for v in range(-5, 6):
    cc = int((c_ac==v).sum())
    sc = int((s_ac==v).sum())
    print("  {:>4} {:>8} {:>8} {:>+6}".format(v, cc, sc, sc-cc))

c0_c = int((c_ac==0).sum())
c0_s = int((s_ac==0).sum())
cp1  = int((c_ac==1).sum()); sp1 = int((s_ac==1).sum())
cn1  = int((c_ac==-1).sum()); sn1 = int((s_ac==-1).sum())
print("\nShrinkage (he so 0 moi): {:+d}".format(c0_s - c0_c))
print("+1: {} -> {:+d} | -1: {} -> {:+d}".format(cp1, sp1-cp1, cn1, sn1-cn1))
print("Ti le +1/-1: {:.3f} -> {:.3f}".format(
    float(cp1)/max(cn1,1), float(sp1)/max(sn1,1)))

print("\nSo sanh LSB vs JSteg vs F3:")
print("  {:22} {:>8} {:>8} {:>8}".format("Tieu chi","LSB","JSteg","F3"))
print("  " + "-"*48)
print("  {:22} {:>8} {:>8} {:>8}".format("Mien giau","Pixel","DCT q","DCT q"))
print("  {:22} {:>8} {:>8} {:>8}".format("Tao he so 0 moi","Khong","Nhieu","It hon"))
print("  {:22} {:>8} {:>8} {:>8}".format("Histogram attack","De","De","Kho hon"))
print("  {:22} {:>8} {:>8} {:>8}".format("Shrinkage","Khong","Khong","Co"))

print("\n[DONE] BUOC 5 HOAN THANH -- chay: stoplab")
