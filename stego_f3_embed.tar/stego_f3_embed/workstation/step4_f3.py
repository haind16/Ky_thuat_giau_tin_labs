#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, json, os

print("=" * 55)
print("  BUOC 4: F3 EMBEDDING")
print("=" * 55)

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

def idct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for j in range(N):
        for k in range(N):
            s = sum(
                (1.0/math.sqrt(2) if u==0 else 1.0)
                *(1.0/math.sqrt(2) if v==0 else 1.0)
                *block[u,v]
                *math.cos((2*j+1)*u*math.pi/16)
                *math.cos((2*k+1)*v*math.pi/16)
                for u in range(N) for v in range(N))
            out[j,k] = 0.25*s
    return out

def to_bits(s):
    bits = []
    for c in s:
        b = ord(c)
        for i in range(7,-1,-1):
            bits.append((b>>i)&1)
    return bits

SECRET = "PTIT_F3_2026"
msg_bits = to_bits(SECRET)
n = len(msg_bits)
header = [(n>>(31-i))&1 for i in range(32)]
all_bits = header + msg_bits

print("Thong diep : '{}' ({} bits + 32-bit header = {} bits tong)".format(
    SECRET, n, len(all_bits)))

print("\nDemo F3 logic (5 vi du):")
print("  {:>6} {:>5} {:>8} {:>10}".format("q","bit","parity","ket qua"))
print("  " + "-"*33)
for q_ex, bit_ex in [(4,1),(3,1),(1,0),(-2,1),(-1,0)]:
    par = abs(q_ex) % 2
    if par == bit_ex:
        res, note = q_ex, "giu nguyen"
    else:
        res = q_ex-1 if q_ex>0 else q_ex+1
        note = "SHRINKAGE" if res==0 else "giam |q|"
    print("  {:>6} {:>5} {:>8} {:>6}  {}".format(q_ex, bit_ex, par, res, note))

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape
stego = arr.copy()
bit_idx = 0
changed = shrink = unchanged = 0

print("\nDang giau {} bits vao {} block...".format(len(all_bits), (H//8)*(W//8)))
for bi in range(H//8):
    for bj in range(W//8):
        if bit_idx >= len(all_bits): break
        r0, c0 = bi*8, bj*8
        b = stego[r0:r0+8, c0:c0+8] - 128.0
        q = np.round(dct2d(b)/Q50).astype(np.int32)
        for (r,c) in ZIGZAG[1:]:
            if bit_idx >= len(all_bits): break
            coef = int(q[r,c])
            if coef == 0: continue
            bit = all_bits[bit_idx]
            if abs(coef)%2 == bit:
                unchanged += 1; bit_idx += 1
            else:
                new = coef-1 if coef>0 else coef+1
                if new == 0:
                    shrink += 1; q[r,c] = 0
                else:
                    q[r,c] = new; changed += 1; bit_idx += 1
        dq = q * Q50
        rec = idct2d(dq) + 128.0
        stego[r0:r0+8, c0:c0+8] = np.clip(np.round(rec),0,255)

os.makedirs('output', exist_ok=True)
Image.fromarray(stego.astype(np.uint8),'L').save('output/stego_f3.png')

mse = np.mean((arr-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse > 0 else 999.0

print("Giau xong: {}/{} bits | changed={} unchanged={} shrinkage={}".format(
    bit_idx, len(all_bits), changed, unchanged, shrink))
print("PSNR     : {:.2f} dB | Shrinkage rate: {:.1f}%".format(
    psnr, shrink/max(changed+unchanged+shrink,1)*100))

meta = {"secret": SECRET, "msg_bits": n, "total_bits": len(all_bits),
        "shrinkage": shrink, "psnr": round(psnr,4)}
with open('output/embed_meta.json','w') as f:
    json.dump(meta, f)

print("\n[OK] So sanh kich thuoc:")
print("[GOI Y] Kiem tra: ls -lh cover.png output/stego_f3.png")
print("[OK] Checksum:")
print("[GOI Y] So sanh: md5sum cover.png output/stego_f3.png")
print("[OK] BUOC 4 HOAN THANH -- chay: python3 step5_analyze.py")
