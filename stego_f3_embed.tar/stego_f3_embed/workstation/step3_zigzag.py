#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, os

print("=" * 55)
print("  BUOC 3: ZIGZAG SCAN")
print("=" * 55)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),
    (2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),
    (3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),
    (3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),
    (6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(block):
    N, out = 8, np.zeros((8,8), dtype=np.float64)
    for u in range(N):
        cu = 1.0/math.sqrt(2) if u==0 else 1.0
        for v in range(N):
            cv = 1.0/math.sqrt(2) if v==0 else 1.0
            s = sum(block[j,k]*math.cos((2*j+1)*u*math.pi/16)
                    *math.cos((2*k+1)*v*math.pi/16)
                    for j in range(N) for k in range(N))
            out[u,v] = 0.25*cu*cv*s
    return out

img = Image.open('cover.png').convert('L')
arr = np.array(img, dtype=np.float64)
b = arr[0:8,0:8] - 128.0
q = np.round(dct2d(b)/Q50).astype(np.int32)

print("Zigzag sequence block (0,0) -- chi nonzero AC:")
print("  {:>4} {:>6} {:>6}   {}".format("idx","(r,c)","q_val","parity"))
print("  " + "-"*35)
shown = 0
for i,(r,c) in enumerate(ZIGZAG):
    if i == 0:
        print("  {:>4} {:>6}  DC={}  (KHONG giau)".format(0,"(0,0)",int(q[0,0])))
        continue
    if q[r,c] != 0 and shown < 12:
        par = abs(int(q[r,c])) % 2
        print("  {:>4} ({},{}) {:>6}   {}".format(i,r,c,int(q[r,c]),par))
        shown += 1

# IN RA MANG 1D ZIGZAG 64 PHAN TU CHO SINH VIEN DE HINH DUNG
zigzag_1d = [int(q[r,c]) for (r,c) in ZIGZAG]
print("\nMang Zigzag 1D (64 phan tu cua block 0,0):")
print(zigzag_1d)

print("\nBan do zigzag tren ma tran 8x8 (thu tu index):")
grid = [[0]*8 for _ in range(8)]
for i,(r,c) in enumerate(ZIGZAG):
    grid[r][c] = i
for row in grid:
    print("  " + " ".join("{:3d}".format(v) for v in row))

print("\nF3 bat dau tu index 1 (AC dau tien), bo qua DC va he so = 0.")
print("[OK] BUOC 3 HOAN THANH -- chay: python3 step4_f3.py")
