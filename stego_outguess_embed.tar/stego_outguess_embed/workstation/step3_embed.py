#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json, hashlib

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(b):
    N=8; out=np.zeros((N,N))
    for u in range(8):
        for v in range(8):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(8) for k in range(8))
    return out

def idct2d(q):
    N=8; out=np.zeros((N,N))
    for j in range(8):
        for k in range(8):
            out[j,k]=0.25*sum((1/math.sqrt(2) if u==0 else 1.0)*(1/math.sqrt(2) if v==0 else 1.0)*q[u,v]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for u in range(8) for v in range(8))
    return out

def lcg(state):
    return (1664525 * state + 1013904223) % (2**32)

def parity(coef):
    return abs(coef) % 2

cover_path = sys.argv[1] if len(sys.argv) > 1 else 'cover.png'
msg        = sys.argv[2] if len(sys.argv) > 2 else 'PTIT_OutGuess_2026'
key        = sys.argv[3] if len(sys.argv) > 3 else 'MySecretKey'
out_path   = sys.argv[4] if len(sys.argv) > 4 else 'stego_og.png'

bits = []
for c in msg:
    v = ord(c)
    for i in range(7,-1,-1): bits.append((v>>i)&1)
n = len(bits)
header = [(n>>(31-i))&1 for i in range(32)]
payload = header + bits

img = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
H, W = img.shape

# Buoc 1: Lay tat ca he so AC != 0, luu gia tri goc
orig_coeff = {}
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        for (r,c) in ZIGZAG[1:]:
            if q[r,c] != 0:
                orig_coeff[(bi,bj,r,c)] = int(q[r,c])

all_pos = list(orig_coeff.keys())
coeff_map = dict(orig_coeff)  # ban sao de chinh sua

# Buoc 2: Shuffle toan bo theo key -> chia doi embed/backup
seed_int = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
state = seed_int
order = list(range(len(all_pos)))
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

half = len(all_pos) // 2
embed_idx  = order[:half]   # nua dau: de giau tin
backup_idx = order[half:]   # nua sau: de correction

embed_positions  = [all_pos[i] for i in embed_idx]
backup_positions = [all_pos[i] for i in backup_idx]

# Buoc 3: EMBED - giau payload vao embed_positions
# OutGuess: neu parity(coef) != bit -> chon tang hoac giam 1
# de minimize distortion, uu tien huong nao lam coef gan 0 hon
hist = {}  # dem histogram hien tai
for pos in all_pos:
    v = coeff_map[pos]
    hist[v] = hist.get(v, 0) + 1

embed_log = []  # ghi lai de hien thi
bit_idx = 0
for pos in embed_positions:
    if bit_idx >= len(payload):
        break
    coef = coeff_map[pos]
    bit  = payload[bit_idx]
    if parity(coef) == bit:
        # Da khop, giu nguyen
        embed_log.append((pos, coef, coef, bit, "khop_san"))
    else:
        # Can doi parity: chon +1 hoac -1
        # OutGuess: uu tien huong nao ma histogram it bi anh huong hon
        c_plus  = coef + 1
        c_minus = coef - 1
        # Khong duoc de thanh 0 (shrinkage)
        if c_plus == 0:
            new_coef = c_minus
        elif c_minus == 0:
            new_coef = c_plus
        else:
            # Chon huong nao ma gia tri dich co histogram nho hon (it bi lo han)
            # neu hist[c_plus] < hist[c_minus]: chuyen ve c_plus it bi nhan ra hon
            if hist.get(c_plus, 0) <= hist.get(c_minus, 0):
                new_coef = c_plus
            else:
                new_coef = c_minus
        # Cap nhat histogram
        hist[coef]     = hist.get(coef, 0) - 1
        hist[new_coef] = hist.get(new_coef, 0) + 1
        coeff_map[pos] = new_coef
        embed_log.append((pos, coef, new_coef, bit, "sua_parity"))
    bit_idx += 1

# Buoc 4: CORRECTION - dung backup_positions de can bang histogram
# Tinh su lech: hist_stego[v] - hist_orig[v]
hist_orig = {}
for pos in all_pos:
    v = orig_coeff[pos]
    hist_orig[v] = hist_orig.get(v, 0) + 1

hist_stego = {}
for pos in all_pos:
    v = coeff_map[pos]
    hist_stego[v] = hist_stego.get(v, 0) + 1

# lech[v] > 0: stego dang thua v so voi goc -> can giam
# lech[v] < 0: stego dang thieu v so voi goc -> can tang
lech = {}
for v in set(list(hist_orig.keys()) + list(hist_stego.keys())):
    d = hist_stego.get(v,0) - hist_orig.get(v,0)
    if d != 0:
        lech[v] = d

correction_log = []
for pos in backup_positions:
    coef = coeff_map[pos]
    if coef == 0:
        continue
    if lech.get(coef, 0) > 0:
        # v dang thua -> thu giam ve c-1 hoac c+1 (ve phia 0)
        new_coef = coef - 1 if coef > 0 else coef + 1
        if new_coef == 0:
            continue
        coeff_map[pos] = new_coef
        lech[coef]     = lech.get(coef, 0) - 1
        lech[new_coef] = lech.get(new_coef, 0) + 1
        correction_log.append({
            "pos": list(pos), "truoc": coef, "sau": new_coef,
            "ly_do": "thua {} -> giam ve {}".format(coef, new_coef)
        })
    elif lech.get(coef, 0) < 0:
        # v dang thieu -> tang ra xa 0
        new_coef = coef + 1 if coef > 0 else coef - 1
        coeff_map[pos] = new_coef
        lech[coef]     = lech.get(coef, 0) + 1
        lech[new_coef] = lech.get(new_coef, 0) - 1
        correction_log.append({
            "pos": list(pos), "truoc": coef, "sau": new_coef,
            "ly_do": "thieu {} -> tang ve {}".format(coef, new_coef)
        })

# Buoc 5: Reconstruct anh stego
stego = img.copy()
block_cache = {}
for (bi,bj,r,c), new_val in coeff_map.items():
    if (bi,bj) not in block_cache:
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        block_cache[(bi,bj)] = q.copy()
    block_cache[(bi,bj)][r,c] = new_val

for (bi,bj), q in block_cache.items():
    rec = idct2d(q.astype(np.float64)*Q50) + 128.0
    stego[bi*8:bi*8+8, bj*8:bj*8+8] = np.clip(np.round(rec), 0, 255)

Image.fromarray(img.astype('uint8'), 'L').save('cover_gray.png')
Image.fromarray(stego.astype('uint8'), 'L').save(out_path)

mse  = np.mean((img-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse > 0 else 999.0

# Chi-square sau correction
hc2 = {}; hs2 = {}
for pos in all_pos:
    hc2[orig_coeff[pos]] = hc2.get(orig_coeff[pos],0)+1
    hs2[coeff_map[pos]]  = hs2.get(coeff_map[pos],0)+1
chi2 = 0.0
for k in range(1,9):
    sp=hs2.get(k,0); sn=hs2.get(-k,0)
    exp=(sp+sn)/2.0 if (sp+sn)>0 else 1
    chi2 += ((sp-exp)**2+(sn-exp)**2)/exp
chi2 = round(chi2, 4)

embed_changed = sum(1 for e in embed_log if e[4]=="sua_parity")

# ---- OUTPUT ----
print("=" * 64)
print("  OUTGUESS EMBED")
print("=" * 64)
print("Message : '{}'  |  Key: '{}'".format(msg, key))
print("PSNR    : {:.2f} dB  |  Chi2: {}".format(psnr, chi2))
print()
print("[1] MANG GIAU TIN  ({} vi tri san co, dung {} de giau {} bits)".format(
    len(embed_positions), bit_idx, len(payload)))
print("    Phuong phap: neu parity(he_so) != bit -> tang hoac giam 1")
print("                 chon huong nao de histogram it bi lo hon")
print()
print("    {:<12} {:<10} {:<10} {:<8} {}".format(
    "Block(bi,bj)", "He_so_goc", "He_so_moi", "Bit", "Ket_qua"))
print("    " + "-" * 56)
for (pos, o, n_, b, ket) in embed_log[:12]:
    bi,bj,r,c = pos
    print("    ({:2d},{:2d})      {:<10} {:<10} {:<8} {}".format(bi,bj,o,n_,b,ket))
print("    ... ({} vi tri tiep theo)".format(bit_idx - 12))
print("    Tong sua parity: {} / {} vi tri".format(embed_changed, bit_idx))
print()
print("[2] MANG BACKUP CORRECTION  ({} vi tri, sua {} he so)".format(
    len(backup_positions), len(correction_log)))
print("    Phuong phap: neu hist_stego[v] > hist_orig[v] (thua v)")
print("                 -> chuyen he so v sang v-1 hoac v+1 de bu lai")
print()
print("    {:<12} {:<10} {:<10} {}".format("Block(bi,bj)", "He_so_goc", "He_so_moi", "Ly_do"))
print("    " + "-" * 60)
for item in correction_log[:12]:
    bi,bj,r,c = item["pos"]
    print("    ({:2d},{:2d})      {:<10} {:<10} {}".format(
        bi,bj,item["truoc"],item["sau"],item["ly_do"]))
print()
print("[3] HIEU QUA CAN BANG HISTOGRAM")
print("    k    +k_goc  -k_goc  +k_stego  -k_stego  lech_truoc  lech_sau")
print("    " + "-" * 64)
for k in range(1,6):
    cp=hc2.get(k,0);  cn=hc2.get(-k,0)
    sp=hs2.get(k,0);  sn=hs2.get(-k,0)
    lt = abs(cp-cn)
    ls = abs(sp-sn)
    nhan = "tot hon" if ls < lt else "chua cai thien"
    print("    {:<5}{:<8}{:<8}{:<10}{:<10}{:<12}{} {}".format(
        k,cp,cn,sp,sn,lt,ls,nhan))
print()
can_bang = sum(1 for k in range(1,6) if abs(hs2.get(k,0)-hs2.get(-k,0)) < abs(hc2.get(k,0)-hc2.get(-k,0)))
print("KET LUAN:")
print("  Giau  : {} bits vao {} vi tri embed, sua parity {} he so".format(len(payload),bit_idx,embed_changed))
print("  Backup: sua {} he so de bu histogram".format(len(correction_log)))
print("  Can bang {}/5 cap (+k,-k) tot hon anh goc".format(can_bang))
if chi2 < 10:
    print("  Chi2={}: rat kho bi phat hien bang chi-square attack".format(chi2))
elif chi2 < 20:
    print("  Chi2={}: kho phat hien bang mat thuong".format(chi2))
else:
    print("  Chi2={}: co the bi phat hien bang chi-square attack".format(chi2))
print()
print("  -> cover_gray.png | {} | embed_log.txt".format(out_path))

with open('embed_log.txt', 'w') as f:
    json.dump({"msg":msg,"key":key,"psnr":round(psnr,4),"chi2":chi2,
               "embed_changed":embed_changed,"corrections":len(correction_log)}, f, indent=2)
