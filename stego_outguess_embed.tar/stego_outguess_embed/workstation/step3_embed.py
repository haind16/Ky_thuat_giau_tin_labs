#!/usr/bin/env python3
import numpy as np, sys, math, json, hashlib
from PIL import Image

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(b):
    out = np.zeros((8,8))
    for u in range(8):
        for v in range(8):
            cu = 1/math.sqrt(2) if u==0 else 1.0
            cv = 1/math.sqrt(2) if v==0 else 1.0
            out[u,v] = 0.25*cu*cv*sum(
                b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                for j in range(8) for k in range(8))
    return out

def idct2d(q):
    out = np.zeros((8,8))
    for j in range(8):
        for k in range(8):
            out[j,k] = 0.25*sum(
                (1/math.sqrt(2) if u==0 else 1.0)*(1/math.sqrt(2) if v==0 else 1.0)
                *q[u,v]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                for u in range(8) for v in range(8))
    return out

def lcg(s): return (1664525*s + 1013904223) % (2**32)

cover_path = sys.argv[1] if len(sys.argv)>1 else 'cover.png'
msg        = sys.argv[2] if len(sys.argv)>2 else 'PTIT_OutGuess_2026'
key        = sys.argv[3] if len(sys.argv)>3 else 'MySecretKey'
out_path   = sys.argv[4] if len(sys.argv)>4 else 'stego_og.png'

bits = []
for c in msg:
    for i in range(7,-1,-1): bits.append((ord(c)>>i)&1)
n = len(bits)
header = [(n>>(31-i))&1 for i in range(32)]
payload = header + bits

img = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
H, W = img.shape

# DCT tat ca block, luu coeff
orig = {}
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        for r,c in ZIGZAG[1:]:
            orig[(bi,bj,r,c)] = int(q[r,c])

coeff = dict(orig)

# Sinh thu tu shuffled tren FIXED space (tat ca AC positions)
all_ac = [(bi,bj,r,c) for bi in range(H//8) for bj in range(W//8) for r,c in ZIGZAG[1:]]
FIXED_N = len(all_ac)

seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
state = seed
order = list(range(FIXED_N))
for i in range(FIXED_N-1, 0, -1):
    state = lcg(state)
    order[i], order[state%(i+1)] = order[state%(i+1)], order[i]

embed_order  = [all_ac[i] for i in order[:FIXED_N//2]]
backup_order = [all_ac[i] for i in order[FIXED_N//2:]]

# Embed: iterate embed_order, bo qua coeff==0
hist = {}
for v in coeff.values(): hist[v] = hist.get(v,0)+1

bit_idx = 0
changed = 0
for pos in embed_order:
    if bit_idx >= len(payload): break
    c = coeff[pos]
    if c == 0: continue
    bit = payload[bit_idx]; bit_idx += 1
    if abs(c) % 2 != bit:
        cp, cm = c+1, c-1
        if cp == 0: new = cm
        elif cm == 0: new = cp
        elif hist.get(cp,0) <= hist.get(cm,0): new = cp
        else: new = cm
        hist[c] = hist.get(c,0)-1
        hist[new] = hist.get(new,0)+1
        coeff[pos] = new; changed += 1

# Correction
hist_orig = {}
for v in orig.values(): hist_orig[v] = hist_orig.get(v,0)+1
hist_stego = {}
for v in coeff.values(): hist_stego[v] = hist_stego.get(v,0)+1
lech = {v: hist_stego.get(v,0)-hist_orig.get(v,0)
        for v in set(list(hist_orig)+list(hist_stego)) if hist_stego.get(v,0)-hist_orig.get(v,0)!=0}

corrections = 0
for pos in backup_order:
    c = coeff[pos]
    if c == 0: continue
    if lech.get(c,0) > 0:
        new = c-1 if c>0 else c+1
        if new == 0: continue
        coeff[pos]=new; lech[c]=lech.get(c,0)-1; lech[new]=lech.get(new,0)+1; corrections+=1
    elif lech.get(c,0) < 0:
        new = c+1 if c>0 else c-1
        coeff[pos]=new; lech[c]=lech.get(c,0)+1; lech[new]=lech.get(new,0)-1; corrections+=1

# Reconstruct
stego = img.copy()
cache = {}
for (bi,bj,r,c),v in coeff.items():
    if (bi,bj) not in cache:
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        cache[(bi,bj)] = q.copy()
    cache[(bi,bj)][r,c] = v
for (bi,bj),q in cache.items():
    rec = idct2d(q.astype(np.float64)*Q50)+128.0
    stego[bi*8:bi*8+8, bj*8:bj*8+8] = np.clip(np.round(rec),0,255)

Image.fromarray(img.astype('uint8'),'L').save('cover_gray.png')
Image.fromarray(stego.astype('uint8'),'L').save(out_path)

mse = np.mean((img-stego)**2)
psnr = 10*math.log10(255**2/mse) if mse>0 else 999.0
print("OutGuess embed: '{}' | PSNR={:.2f}dB | corrections={} | {}".format(msg,psnr,corrections,out_path))

with open('embed_log.txt','w') as f:
    json.dump({"msg":msg,"key":key,"psnr":round(psnr,4),"changed":changed,"corrections":corrections},f,indent=2)
