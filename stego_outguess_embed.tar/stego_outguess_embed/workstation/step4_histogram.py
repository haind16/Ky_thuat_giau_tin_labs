#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(b):
    N=8; out=np.zeros((N,N))
    for u in range(8):
        for v in range(8):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(8) for k in range(8))
    return out

def get_ac_hist(arr):
    H, W = arr.shape
    hist = {}
    for bi in range(H//8):
        for bj in range(W//8):
            q = np.rint(dct2d(arr[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
            for u in range(8):
                for v in range(8):
                    if u==0 and v==0: continue
                    hist[int(q[u,v])] = hist.get(int(q[u,v]), 0) + 1
    return hist

cover_path = sys.argv[1] if len(sys.argv) > 1 else 'cover.png'
stego_path = sys.argv[2] if len(sys.argv) > 2 else 'stego_og.png'
out_path   = sys.argv[3] if len(sys.argv) > 3 else 'histogram_diff.txt'

cover = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
stego = np.array(Image.open(stego_path).convert('L'), dtype=np.float64)

diff_px = np.abs(cover - stego)
mse = np.mean(diff_px**2)
psnr = 10*math.log10(255**2/mse) if mse > 0 else 999.0

hc = get_ac_hist(cover)
hs = get_ac_hist(stego)

# Chi-square statistic on pairs (-k, k) for k=1..8
pairs = {}
for k in range(1, 9):
    nc_pos = hc.get(k, 0); nc_neg = hc.get(-k, 0)
    ns_pos = hs.get(k, 0); ns_neg = hs.get(-k, 0)
    pairs[k] = {
        "cover_pos": nc_pos, "cover_neg": nc_neg,
        "stego_pos": ns_pos, "stego_neg": ns_neg,
        "symmetry_cover": round(nc_pos/(nc_neg+1e-9), 3),
        "symmetry_stego": round(ns_pos/(ns_neg+1e-9), 3)
    }

result = {
    "psnr": round(psnr, 4),
    "mse": round(mse, 6),
    "pixel_changed": int((diff_px > 0).sum()),
    "histogram": {str(k): {"cover": hc.get(k,0), "stego": hs.get(k,0), "diff": hs.get(k,0)-hc.get(k,0)} for k in range(-8,9)},
    "symmetry_pairs": pairs
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("histogram analysis done | PSNR={:.2f}dB | changed pixels={}".format(psnr, int((diff_px>0).sum())))
print("Symmetry +1/-1: cover={:.3f} stego={:.3f}".format(
    hc.get(1,0)/(hc.get(-1,0)+1e-9),
    hs.get(1,0)/(hs.get(-1,0)+1e-9)))
print("Saved -> {}".format(out_path))
