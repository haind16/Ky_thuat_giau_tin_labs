#!/usr/bin/env python3
import numpy as np
from PIL import Image
import math, sys, json

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

def dct2d(b):
    N=8; out=np.zeros((N,N))
    for u in range(8):
        for v in range(8):
            cu=1/math.sqrt(2) if u==0 else 1.0
            cv=1/math.sqrt(2) if v==0 else 1.0
            out[u,v]=0.25*cu*cv*sum(b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16) for j in range(8) for k in range(8))
    return out

img_path = sys.argv[1] if len(sys.argv) > 1 else 'cover.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'dct_stats.txt'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape

usable = []
hist = {}
for bi in range(H//8):
    for bj in range(W//8):
        q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
        for u in range(8):
            for v in range(8):
                if u==0 and v==0: continue
                val = int(q[u,v])
                if val != 0:
                    usable.append((bi, bj, u, v, val))
                hist[val] = hist.get(val, 0) + 1

result = {
    "image": img_path,
    "size": "{}x{}".format(W, H),
    "blocks": (H//8)*(W//8),
    "nonzero_ac": len(usable),
    "capacity_bytes": len(usable)//8,
    "hist_sample": {str(k): hist[k] for k in sorted(hist) if abs(k) <= 5}
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("nonzero AC: {} | capacity ~{} bytes | saved -> {}".format(
    len(usable), len(usable)//8, out_path))
