=== LAB: GIAU TIN BANG OUTGUESS (DCT + KEY-BASED PRNG) ===

B0: Kiem tra anh goc
  file cover.png
  exiftool cover.png
  xxd cover.png | head -4

B1: Quet he so DCT va xuat thong ke
  python3 step1_scan.py cover.png dct_stats.txt
  cat dct_stats.txt

B2: Tao thu tu nhung theo key (PRNG)
  python3 step2_sequence.py dct_stats.txt "MySecretKey" sequence.txt
  cat sequence.txt

B3: Nhung tin vao anh stego
  python3 step3_embed.py cover.png "PTIT_OutGuess_2026" "MySecretKey" stego_og.png
  cat embed_log.txt

B4: Phan tich histogram truoc/sau
  python3 step4_histogram.py cover_gray.png stego_og.png histogram_diff.txt
  cat histogram_diff.txt

B5: Xem va so sanh anh (cung dinh dang grayscale)
  eog cover_gray.png &
  eog stego_og.png &

B6: Checksum
  md5sum cover_gray.png stego_og.png

XONG: stoplab
