#!/usr/bin/env python3
import sys, json, hashlib

stats_path = sys.argv[1] if len(sys.argv) > 1 else 'dct_stats.txt'
key        = sys.argv[2] if len(sys.argv) > 2 else 'MySecretKey'
out_path   = sys.argv[3] if len(sys.argv) > 3 else 'sequence.txt'

with open(stats_path) as f:
    stats = json.load(f)

capacity = stats['nonzero_ac']

# OutGuess: tạo thứ tự nhúng giả ngẫu nhiên từ key (PRNG seeded by key)
seed_int = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)

def lcg(state):
    # Linear Congruential Generator
    return (1664525 * state + 1013904223) % (2**32)

state = seed_int
order = list(range(capacity))
# Fisher-Yates shuffle theo key
for i in range(len(order)-1, 0, -1):
    state = lcg(state)
    j = state % (i+1)
    order[i], order[j] = order[j], order[i]

result = {
    "key": key,
    "key_hash": hashlib.sha256(key.encode()).hexdigest()[:16],
    "capacity": capacity,
    "order_preview": order[:20],
    "order_tail": order[-5:]
}

with open(out_path, 'w') as f:
    json.dump(result, f, indent=2)

print("Key: '{}' | PRNG order generated for {} slots | saved -> {}".format(
    key, capacity, out_path))
print("Order preview (first 10): {}".format(order[:10]))
