=== LAB: TACH TIN OUTGUESS ===

B0: Kiem tra file stego
  file stego_og.png
  xxd stego_og.png | head -4

B1: Trich xuat he so DCT tu anh stego
  python3 step1_dct.py stego_og.png coeff_raw.txt
  wc -l coeff_raw.txt && head -5 coeff_raw.txt

B2: Tao lai keystream tu key
  cat key.txt
  python3 step2_keystream.py key.txt coeff_raw.txt keystream.txt
  head -3 keystream.txt

B3: Giai ma bit stream
  python3 step3_decode.py coeff_raw.txt keystream.txt bits.txt
  head -1 bits.txt | cut -c1-60

B4: Khoi phuc tin nhan
  python3 step4_recover.py bits.txt message.txt
  cat message.txt

B5: Xac minh ket qua
  diff <(cat message.txt) <(echo "PTIT_OutGuess_2026") && echo "[MATCH]"
  eog stego_og.png &
  md5sum stego_og.png

XONG: stoplab
