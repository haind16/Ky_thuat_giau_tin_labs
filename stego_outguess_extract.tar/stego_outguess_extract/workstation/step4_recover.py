#!/usr/bin/env python3
import sys

bits_path = sys.argv[1] if len(sys.argv) > 1 else 'bits.txt'
out_path  = sys.argv[2] if len(sys.argv) > 2 else 'message.txt'

with open(bits_path) as f:
    lines = f.readlines()

bitstr = ""
for line in lines:
    if line.startswith("total"): continue
    bitstr += line.strip()

bits = [int(b) for b in bitstr if b in '01']

if len(bits) < 32:
    print("ERROR: not enough bits"); sys.exit(1)

msg_len = int("".join(str(b) for b in bits[:32]), 2)

if msg_len <= 0 or 32 + msg_len > len(bits):
    print("ERROR: invalid header (len={})".format(msg_len)); sys.exit(1)

msg_bits = bits[32:32 + msg_len]
chars = []
for i in range(0, len(msg_bits) // 8 * 8, 8):
    chars.append(chr(int("".join(str(b) for b in msg_bits[i:i+8]), 2)))

message = "".join(chars)
with open(out_path, 'w') as f:
    f.write(message + "\n")

print("message ({} chars): {}".format(len(message), message))
