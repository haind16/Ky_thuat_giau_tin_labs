#!/usr/bin/env python3
import numpy as np, sys, math
from PIL import Image

Q50 = np.array([
    [16,11,10,16,24,40,51,61],[12,12,14,19,26,58,60,55],
    [14,13,16,24,40,57,69,56],[14,17,22,29,51,87,80,62],
    [18,22,37,56,68,109,103,77],[24,35,55,64,81,104,113,92],
    [49,64,78,87,103,121,120,101],[72,92,95,98,112,100,103,99]
], dtype=np.float64)

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

def dct2d(b):
    out = np.zeros((8,8))
    for u in range(8):
        for v in range(8):
            cu = 1/math.sqrt(2) if u==0 else 1.0
            cv = 1/math.sqrt(2) if v==0 else 1.0
            out[u,v] = 0.25*cu*cv*sum(
                b[j,k]*math.cos((2*j+1)*u*math.pi/16)*math.cos((2*k+1)*v*math.pi/16)
                for j in range(8) for k in range(8))
    return out

img_path = sys.argv[1] if len(sys.argv) > 1 else 'stego_og.png'
out_path = sys.argv[2] if len(sys.argv) > 2 else 'coeff_raw.txt'

img = np.array(Image.open(img_path).convert('L'), dtype=np.float64)
H, W = img.shape
count = 0

with open(out_path, 'w') as f:
    f.write("{}x{}\n".format(W, H))
    for bi in range(H//8):
        for bj in range(W//8):
            q = np.rint(dct2d(img[bi*8:bi*8+8, bj*8:bj*8+8]-128.0)/Q50).astype(int)
            for r,c in ZIGZAG[1:]:
                if q[r,c] != 0:
                    f.write("{},{},{},{},{}\n".format(bi,bj,r,c,int(q[r,c])))
                    count += 1

print("{}: {} AC nonzero -> {}".format(img_path, count, out_path))
