#!/usr/bin/env python3
import sys, hashlib

key_file   = sys.argv[1] if len(sys.argv)>1 else 'key.txt'
coeff_path = sys.argv[2] if len(sys.argv)>2 else 'coeff_raw.txt'
out_path   = sys.argv[3] if len(sys.argv)>3 else 'keystream.txt'

with open(key_file) as f:
    key = f.read().strip()

with open(coeff_path) as f:
    size_line = f.readline().strip()  # "512x512"

W, H = [int(x) for x in size_line.split('x')]
FIXED_N = (W//8)*(H//8)*63

seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**31)
def lcg(s): return (1664525*s+1013904223) % (2**32)

state = seed
order = list(range(FIXED_N))
for i in range(FIXED_N-1, 0, -1):
    state = lcg(state)
    order[i], order[state%(i+1)] = order[state%(i+1)], order[i]

embed_indices = order[:FIXED_N//2]

with open(out_path, 'w') as f:
    f.write("{}x{}\n".format(W, H))
    f.write("{}\n".format(len(embed_indices)))
    for idx in embed_indices:
        f.write("{}\n".format(idx))

print("key='{}' | FIXED_N={} | embed slots: {} -> {}".format(key, FIXED_N, len(embed_indices), out_path))
