#!/usr/bin/env python3
import sys

coeff_path = sys.argv[1] if len(sys.argv)>1 else 'coeff_raw.txt'
key_path   = sys.argv[2] if len(sys.argv)>2 else 'keystream.txt'
out_path   = sys.argv[3] if len(sys.argv)>3 else 'bits.txt'

ZIGZAG = [
    (0,0),(0,1),(1,0),(2,0),(1,1),(0,2),(0,3),(1,2),(2,1),(3,0),(4,0),(3,1),(2,2),(1,3),(0,4),(0,5),
    (1,4),(2,3),(3,2),(4,1),(5,0),(6,0),(5,1),(4,2),(3,3),(2,4),(1,5),(0,6),(0,7),(1,6),(2,5),(3,4),
    (4,3),(5,2),(6,1),(7,0),(7,1),(6,2),(5,3),(4,4),(3,5),(2,6),(1,7),(2,7),(3,6),(4,5),(5,4),(6,3),
    (7,2),(7,3),(6,4),(5,5),(4,6),(3,7),(4,7),(5,6),(6,5),(7,4),(7,5),(6,6),(5,7),(6,7),(7,6),(7,7)
]

# Doc coeff_raw -> dict (bi,bj,r,c):val
with open(coeff_path) as f:
    size_line = f.readline().strip()
    coeff_dict = {}
    for line in f:
        parts = line.strip().split(',')
        if len(parts)==5:
            bi,bj,r,c,v = int(parts[0]),int(parts[1]),int(parts[2]),int(parts[3]),int(parts[4])
            coeff_dict[(bi,bj,r,c)] = v

W, H = [int(x) for x in size_line.split('x')]

# Xay dung all_ac theo dung thu tu nhu embed
all_ac = [(bi,bj,r,c) for bi in range(H//8) for bj in range(W//8) for r,c in ZIGZAG[1:]]

# Doc keystream
with open(key_path) as f:
    f.readline()  # size line
    f.readline()  # count
    embed_indices = [int(l.strip()) for l in f if l.strip().isdigit()]

# Doc bit: iterate embed_indices theo thu tu, bo qua coeff==0
bits = []
for idx in embed_indices:
    pos = all_ac[idx]
    v = coeff_dict.get(pos, 0)
    if v == 0: continue
    bits.append(abs(v) % 2)

with open(out_path, 'w') as f:
    f.write("bits={}\n".format("".join(str(b) for b in bits)))

print("decoded: {} bits -> {}".format(len(bits), out_path))
